package laggyboi.vivemonkecraftserver;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Packet sent server → client on join.
 *
 * Wire format MUST match the client mod's mirror class exactly:
 *   boolean modEnabled, then 10 doubles in the order below.
 *
 * Enforced limits: modEnabled, maxJumpSpeed (backed up by MovementEnforcer).
 * Allowances: per-setting limits the admin GRANTS to every player, replacing
 * the client mod's built-in default caps (which apply to players without
 * cheats/op). 0 = not granted (max-type), -1 = not granted (min-type:
 * gravity / air friction, where 0 is a meaningful "allow everything" value).
 */
public record ServerConfigPayload(
        boolean modEnabled,
        double  maxJumpSpeed,
        double  allowPushStrength,
        double  allowJumpMultiplier,
        double  allowMaxJumpSpeed,
        double  allowHandReach,
        double  allowArmLength,
        double  allowStepHeight,
        double  allowHandRadius,
        double  allowGravityMin,
        double  allowAirFrictionMin
) implements class_8710 {

    public static final class_8710.class_9154<ServerConfigPayload> ID =
            new class_8710.class_9154<>(
                    class_2960.method_60655("vivemonkecraft", "server_cfg"));

    public static final class_9139<class_2540, ServerConfigPayload> STREAM_CODEC =
            class_9139.method_56437(ServerConfigPayload::encode, ServerConfigPayload::decode);

    private static void encode(class_2540 buf, ServerConfigPayload p) {
        buf.method_52964(p.modEnabled());
        buf.method_52940(p.maxJumpSpeed());
        buf.method_52940(p.allowPushStrength());
        buf.method_52940(p.allowJumpMultiplier());
        buf.method_52940(p.allowMaxJumpSpeed());
        buf.method_52940(p.allowHandReach());
        buf.method_52940(p.allowArmLength());
        buf.method_52940(p.allowStepHeight());
        buf.method_52940(p.allowHandRadius());
        buf.method_52940(p.allowGravityMin());
        buf.method_52940(p.allowAirFrictionMin());
    }

    private static ServerConfigPayload decode(class_2540 buf) {
        return new ServerConfigPayload(
                buf.readBoolean(),
                buf.readDouble(), buf.readDouble(), buf.readDouble(),
                buf.readDouble(), buf.readDouble(), buf.readDouble(),
                buf.readDouble(), buf.readDouble(), buf.readDouble(),
                buf.readDouble()
        );
    }

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
