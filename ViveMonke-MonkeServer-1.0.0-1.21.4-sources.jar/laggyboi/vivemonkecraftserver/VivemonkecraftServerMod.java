package laggyboi.vivemonkecraftserver;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1324;
import net.minecraft.class_5134;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Server-side companion mod for ViveMonke(Quest)Craft.
 *
 * On every player join, this mod sends a {@link ServerConfigPayload}
 * to that player.  The client mod reads the packet and applies the
 * server's movement limits (or disables itself entirely if
 * {@code modEnabled} is {@code false}).
 *
 * The config lives at:
 *   <server-root>/config/vivemonkecraft-server.properties
 */
public class VivemonkecraftServerMod implements ModInitializer {

    public static final Logger LOGGER =
            LoggerFactory.getLogger("vivemonkecraft-server");

    @Override
    public void onInitialize() {
        LOGGER.info("ViveMonke(Quest)Craft Server Config — initialising...");

        // 1. Read server config from disk (creates default file if absent)
        ServerModConfig.load();

        // 2. Register the S2C payload type.
        //    Must be done once during init so Fabric knows how to encode it.
        PayloadTypeRegistry.playS2C().register(
                ServerConfigPayload.ID,
                ServerConfigPayload.STREAM_CODEC
        );

        // 3. Register server-side movement enforcement (works even without the client mod).
        MovementEnforcer.register();

        // 3b. Real Monke: the client asks us to shrink its collision box HEIGHT
        //     (only the height — the SCALE attribute was rejected because it
        //     shrinks width, model and reach too). We track who opted in and
        //     ServerPlayerHitboxMixin applies the height cap on the server's
        //     box, so movement validation agrees with the client's shrunk box
        //     and 1-block tunnels work. Fabric runs this handler on the server
        //     thread, so touching the player here is safe.
        PayloadTypeRegistry.playC2S().register(
                RealMonkeC2SPayload.ID,
                RealMonkeC2SPayload.STREAM_CODEC
        );
        ServerPlayNetworking.registerGlobalReceiver(
                RealMonkeC2SPayload.ID,
                (payload, context) -> {
                    RealMonkeTracker.set(context.player().method_5667(), payload.enabled());
                    context.player().method_18382();
                }
        );
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            RealMonkeTracker.remove(handler.field_14140.method_5667());
            // Tell everyone the leaver's monke model is gone.
            if (MonkeModelTracker.isOn(handler.field_14140.method_5667())) {
                MonkeModelTracker.remove(handler.field_14140.method_5667());
                MonkeModelS2CPayload off =
                        new MonkeModelS2CPayload(handler.field_14140.method_5667(), false);
                for (var p : net.fabricmc.fabric.api.networking.v1.PlayerLookup.all(server)) {
                    ServerPlayNetworking.send(p, off);
                }
            }
        });

        // 3c. Monke model (legless look) sync: a client announces its toggle and
        //     we broadcast it to every player, so all mod users see each other
        //     without legs. Joiners get the full current set replayed (below).
        PayloadTypeRegistry.playC2S().register(
                MonkeModelC2SPayload.ID,
                MonkeModelC2SPayload.STREAM_CODEC
        );
        PayloadTypeRegistry.playS2C().register(
                MonkeModelS2CPayload.ID,
                MonkeModelS2CPayload.STREAM_CODEC
        );
        ServerPlayNetworking.registerGlobalReceiver(
                MonkeModelC2SPayload.ID,
                (payload, context) -> {
                    MonkeModelTracker.set(context.player().method_5667(), payload.enabled());
                    MonkeModelS2CPayload sync = new MonkeModelS2CPayload(
                            context.player().method_5667(), payload.enabled());
                    for (var p : net.fabricmc.fabric.api.networking.v1.PlayerLookup.all(
                            context.player().method_5682())) {
                        ServerPlayNetworking.send(p, sync);
                    }
                }
        );

        // 4. Send our config to every player the moment they finish joining.
        //    Operators (permission level 2+) bypass the modEnabled ban so admins
        //    can still use the mod on their own server.
        //    This runs on the server thread, so ServerPlayNetworking.send() is safe here.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            // Cleanup: an earlier Real Monke build used the SCALE attribute, which
            // persists in player NBT. Reset any leftover shrink from those builds.
            class_1324 scale = handler.field_14140.method_5996(class_5134.field_47760);
            if (scale != null && scale.method_6201() != 1.0) {
                scale.method_6192(1.0);
            }

            // Replay the current monke-model set to the joiner so already-legless
            // players render correctly from the first frame.
            for (java.util.UUID monke : MonkeModelTracker.all()) {
                ServerPlayNetworking.send(handler.field_14140,
                        new MonkeModelS2CPayload(monke, true));
            }

            // Players at or above opBypassLevel get modEnabled=true and no speed cap,
            // regardless of what the config says. (Ops also bypass the client-side
            // setting caps via their permission level, so allowances don't matter
            // for them — they're sent the same allowances as everyone anyway.)
            boolean isOp = handler.field_14140.method_64475(ServerModConfig.opBypassLevel);

            ServerPlayNetworking.send(
                    handler.field_14140,
                    new ServerConfigPayload(
                            isOp || ServerModConfig.modEnabled,
                            isOp ? 0.0 : ServerModConfig.maxJumpSpeed,
                            ServerModConfig.allowPushStrength,
                            ServerModConfig.allowJumpMultiplier,
                            ServerModConfig.allowMaxJumpSpeed,
                            ServerModConfig.allowHandReach,
                            ServerModConfig.allowArmLength,
                            ServerModConfig.allowStepHeight,
                            ServerModConfig.allowHandRadius,
                            ServerModConfig.allowGravityMin,
                            ServerModConfig.allowAirFrictionMin
                    )
            );
        });

        LOGGER.info("ViveMonke(Quest)Craft Server Config — ready.");
    }
}
