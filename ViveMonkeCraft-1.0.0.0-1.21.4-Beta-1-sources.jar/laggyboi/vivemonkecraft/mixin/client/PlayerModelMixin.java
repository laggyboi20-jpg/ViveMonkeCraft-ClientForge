package laggyboi.vivemonkecraft.mixin.client;

import laggyboi.vivemonkecraft.client.MovementConfig;
import laggyboi.vivemonkecraft.client.VmcMonkeRenderState;
import net.minecraft.class_10055;
import net.minecraft.class_591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// =====================================================================
// MONKE MODEL (mixin) - the Gorilla Tag body: no legs, shorter torso
// =====================================================================
//
// Runs at the END of PlayerModel.setupAnim, after vanilla (and Vivecraft's
// super-call) has posed every part:
//   * MONKE MODEL (flagged players): legs hidden, torso/arm/head tuning.
//   * HIDE OWN HEAD (your own first-person body while the VR view is dropped):
//     hide ONLY the head + hat so you don't see inside your own head.
//
// Both run independently and the transforms always execute when monke is on,
// so torso rotation works even with the view dropped (an earlier version
// early-returned for "hide own body" and silently killed the transforms).
//
// priority 2000 so we apply after Vivecraft's own model adjustments.
// =====================================================================
@Mixin(value = class_591.class, priority = 2000)
public class PlayerModelMixin {

    @Inject(
        method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;)V",
        at = @At("TAIL"),
        require = 0
    )
    private void vmc$monkeBody(class_10055 state, CallbackInfo ci) {
        if (!(state instanceof VmcMonkeRenderState monke)) return;

        class_591 self = (class_591) (Object) this;

        // ---- MONKE MODEL transforms (legless body, torso/arm/head tuning) ----
        // Runs whenever this player is flagged monke, INCLUDING your own body while
        // the view is dropped, so the torso rotation etc. actually take effect.
        if (monke.vmc$isMonke()) {
            // CUT OFF THE LEGS (and their second-layer overlays).
            self.field_3397.field_3665    = false;
            self.field_3392.field_3665   = false;
            self.field_3482.field_3665  = false;
            self.field_3479.field_3665 = false;
            self.field_3483.field_3665     = false;
            self.field_3484.field_3665 = false;
            self.field_3486.field_3665= false;
            self.field_3394.field_3665        = false;

            // TORSO: offset (+Y is down in model space), lean, and shorten.
            self.field_3391.field_3656    += (float) MovementConfig.modelTorsoOffsetY;
            self.field_3391.field_3654 += (float) Math.toRadians(MovementConfig.modelTorsoPitch);
            self.field_3391.field_37939 *= (float) MovementConfig.modelTorsoScaleY;
            self.field_3483.method_17138(self.field_3391);

            // ARMS: vertical offset + rotation (added on top of the swing animation).
            float armPitch = (float) Math.toRadians(MovementConfig.modelArmsPitch);
            self.field_27433.field_3656    += (float) MovementConfig.modelArmsOffsetY;
            self.field_3401.field_3656   += (float) MovementConfig.modelArmsOffsetY;
            self.field_27433.field_3654  += armPitch;
            self.field_3401.field_3654 += armPitch;
            self.field_3484.method_17138(self.field_27433);
            self.field_3486.method_17138(self.field_3401);

            // HEAD: vertical offset + rotation; hat layer follows.
            self.field_3398.field_3656    += (float) MovementConfig.modelHeadOffsetY;
            self.field_3398.field_3654 += (float) Math.toRadians(MovementConfig.modelHeadPitch);
            self.field_3394.method_17138(self.field_3398);
        }

        // NOTE: no head-hide here. With the collision-only hitbox shrink (eye height
        // + attachments preserved, see PlayerHitboxMixin) the head model stays at
        // full height, above the dropped VR view — so it's never in the way and your
        // skin's head renders normally, exactly like the dev-20 build.
    }
}
