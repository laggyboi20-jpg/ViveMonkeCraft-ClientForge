package laggyboi.vivemonkecraft.mixin.client;

import laggyboi.vivemonkecraft.client.EmbeddedServerLogic;
import laggyboi.vivemonkecraft.client.MovementConfig;
import laggyboi.vivemonkecraft.client.VivemonkecraftClient;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// =====================================================================
// SHORTER HITBOX (mixin) — "delete the legs" for climbing
// =====================================================================
//
// A Minecraft player is ONE collision box (~0.6 wide x 1.8 tall) anchored at
// the feet — there are no separate "leg" boxes. So to stop your lower body
// catching on block edges when you climb, we make that box SHORTER.
//
// We hook getDimensions() (which decides the player's box size) and, only for
// YOUR player and only while the mod is on, scale the HEIGHT down.
// =====================================================================

// TARGET: Player#getDefaultDimensions — NOT Entity#getDimensions! Since 1.20.5,
// LivingEntity overrides getDimensions() as getDefaultDimensions(pose).scale(getScale())
// without calling super, so an Entity.getDimensions injection NEVER RUNS for
// players (it was silently dead — and exactly why only the SCALE attribute,
// which feeds getScale(), ever managed to shrink the box).
// priority 2000 (default 1000): Vivecraft also manages player sizing/poses —
// applying later means OUR setReturnValue runs last and wins.
@Mixin(value = class_1657.class, priority = 2000)
public class PlayerHitboxMixin {

    // require = 0 -> if Mojang renames this in a future version, we just skip the
    // shrink instead of crashing.
    @Inject(
        method = "getDefaultDimensions(Lnet/minecraft/world/entity/Pose;)Lnet/minecraft/world/entity/EntityDimensions;",
        at = @At("RETURN"),
        cancellable = true,
        require = 0
    )
    private void vmc$shrinkHitbox(class_4050 pose, CallbackInfoReturnable<class_4048> cir) {
        // Apply to the local player on BOTH logical sides of this JVM:
        //   - LocalPlayer: the client-side entity (what your own collision uses)
        //   - the integrated server's ServerPlayer with OUR uuid (singleplayer /
        //     LAN host): the server validates movement against ITS box — if it
        //     stayed 1.8 tall, walking into a 1-block tunnel would be rubber-
        //     banded back even though the client box fits. Matching both sides
        //     is what makes tunnels actually work in singleplayer.
        //     (On dedicated servers the monke-server companion does this half.)
        Object self = this;

        // Is this OUR OWN player (the client entity, or the integrated server's copy
        // of us when hosting)? Our own box follows OUR live MovementConfig.
        boolean own;
        if (self instanceof class_746) {
            own = true;
        } else if (self instanceof class_3222 sp) {
            class_746 lp = class_310.method_1551().field_1724;
            own = lp != null && sp.method_5667().equals(lp.method_5667());
        } else {
            return;
        }

        if (own) {
            // Only while the mod is on.
            if (!VivemonkecraftClient.isEnabled()) return;

            class_4048 original = cir.getReturnValue();
            class_4048 dims     = original;

            // Scale HEIGHT only (1.0 width factor, `scale` height factor).
            double scale = MovementConfig.hitboxHeightScale;
            if (scale < 1.0 && scale > 0.0) {
                dims = dims.method_19539(1.0f, (float) scale);
            }

            // REAL MONKE: cap the box at 0.5 blocks — half of the ~2 m player, a true
            // one-block monke. 0.5 (not ~0.95) so there's real clearance in a 1-block
            // tunnel: at 0.95 any upward push (step assist, swing) pressed the box
            // into the ceiling and the server wedged/rubber-banded the movement.
            if (MovementConfig.realMonke && dims.comp_2186() > 0.5f) {
                dims = dims.method_19539(1.0f, 0.5f / dims.comp_2186());
            }

            if (dims != original) {
                cir.setReturnValue(vmc$collisionOnly(dims, original));
            }
            return;
        }

        // GUEST on our integrated server (LAN host): shrink any ServerPlayer who has
        // told us (via the embedded Real Monke receiver) that they're gorilla-sized,
        // so the host's movement validation agrees and their 1-block tunnels work.
        // Driven purely by the guest's request — NOT the host's own config.
        if (self instanceof class_3222 sp
                && EmbeddedServerLogic.realMonkePlayers.contains(sp.method_5667())) {
            class_4048 original = cir.getReturnValue();
            if (original.comp_2186() > 0.5f) {
                class_4048 dims = original.method_19539(1.0f, 0.5f / original.comp_2186());
                cir.setReturnValue(vmc$collisionOnly(dims, original));
            }
        }
    }

    // COLLISION-ONLY shrink: EntityDimensions.scale() also scales eyeHeight and the
    // render ATTACHMENTS, and Vivecraft anchors the player model (head, 3D layers,
    // VR body) off those — so scaling them dragged the model down and put your own
    // head into the camera. Rebuild with the shrunk box but the ORIGINAL eye height
    // and attachments, so ONLY collision changes and the model stays full-size and
    // correctly positioned (this is why the head was never in the way in dev-20).
    @org.spongepowered.asm.mixin.Unique
    private static class_4048 vmc$collisionOnly(class_4048 shrunk, class_4048 original) {
        return new class_4048(
                shrunk.comp_2185(), shrunk.comp_2186(),
                original.comp_2187(), original.comp_2188(), shrunk.comp_2189());
    }
}
