package laggyboi.vivemonkecraft.client;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Client → server: "my monke model (legless look) is on/off".
 * The server tracks it and broadcasts {@code monke_model_sync} to everyone so
 * every player with the mod renders me accordingly.
 *
 * Wire format: one boolean. MUST match the server mod's mirror class.
 */
public record MonkeModelC2SPayload(boolean enabled) implements class_8710 {

    public static final class_8710.class_9154<MonkeModelC2SPayload> ID =
            new class_8710.class_9154<>(
                    class_2960.method_60655("vivemonkecraft", "monke_model"));

    public static final class_9139<class_2540, MonkeModelC2SPayload> STREAM_CODEC =
            class_9139.method_56437(
                    (buf, p) -> buf.method_52964(p.enabled()),
                    buf -> new MonkeModelC2SPayload(buf.readBoolean()));

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
