package laggyboi.vivemonkecraft.client;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Client → server request: apply Real Monke (height-only hitbox shrink) to me.
 *
 * The server validates movement against ITS copy of the player's box, so the
 * shrink must exist server-side too or 1-block tunnels get rubber-banded. On a
 * dedicated server the monke-server companion tracks who opted in and caps
 * their box height via its own mixin. The packet carries only on/off intent.
 *
 * Wire format: one boolean. MUST match the server mod's mirror class.
 */
public record RealMonkeC2SPayload(boolean enabled) implements class_8710 {

    public static final class_8710.class_9154<RealMonkeC2SPayload> ID =
            new class_8710.class_9154<>(
                    class_2960.method_60655("vivemonkecraft", "real_monke"));

    public static final class_9139<class_2540, RealMonkeC2SPayload> STREAM_CODEC =
            class_9139.method_56437(
                    (buf, p) -> buf.method_52964(p.enabled()),
                    buf -> new RealMonkeC2SPayload(buf.readBoolean()));

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
