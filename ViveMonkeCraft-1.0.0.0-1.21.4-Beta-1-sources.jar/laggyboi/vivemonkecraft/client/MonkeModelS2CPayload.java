package laggyboi.vivemonkecraft.client;

import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Server → client: "player <uuid> has the monke model (legless look) on/off".
 * Sent to everyone when a player toggles, and replayed to joiners so they get
 * the full current set.
 *
 * Wire format: UUID + boolean. MUST match the server mod's mirror class.
 */
public record MonkeModelS2CPayload(UUID player, boolean enabled) implements class_8710 {

    public static final class_8710.class_9154<MonkeModelS2CPayload> ID =
            new class_8710.class_9154<>(
                    class_2960.method_60655("vivemonkecraft", "monke_model_sync"));

    public static final class_9139<class_2540, MonkeModelS2CPayload> STREAM_CODEC =
            class_9139.method_56437(
                    (buf, p) -> { buf.method_10797(p.player()); buf.method_52964(p.enabled()); },
                    buf -> new MonkeModelS2CPayload(buf.method_10790(), buf.readBoolean()));

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
