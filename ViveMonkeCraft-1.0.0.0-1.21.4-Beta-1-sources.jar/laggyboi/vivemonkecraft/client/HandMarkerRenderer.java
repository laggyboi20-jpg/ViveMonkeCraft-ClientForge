package laggyboi.vivemonkecraft.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

// =====================================================================
// HAND MARKER RENDERER
// =====================================================================
//
// Replaces the old particle hand markers with per-frame geometry drawn
// directly into the world render pipeline via WorldRenderEvents.
// Zero particles, zero entities — best performance for Quest standalone,
// and fully client-side so it works on any server.
//
// Draws an arm line per hand (shoulder → grab point) plus a wireframe cube at
// the grab point matching the hand hitbox size.
// Green when gripping a block, red when free. Lines only.
//
// State fields are written once per game tick by GorillaLocomotionHandler
// and read every render frame here.
// =====================================================================

public final class HandMarkerRenderer {

    private HandMarkerRenderer() {}

    // =========================================================================
    // Tick-to-frame state — written by GorillaLocomotionHandler, read per frame
    // =========================================================================

    // Shoulder joint positions (world-space), computed from headPositon + player yaw
    // each tick so they track the player model's arm sockets.
    public static class_243    shoulderMain = null;
    public static class_243    shoulderOff  = null;

    // Grab / touch points — where the hand hitbox currently lands.
    public static class_243    grabMain     = null;
    public static class_243    grabOff      = null;

    public static boolean grippingMain = false;
    public static boolean grippingOff  = false;

    public static void clearState() {
        shoulderMain = shoulderOff = grabMain = grabOff = null;
        grippingMain = grippingOff = false;
    }

    // =========================================================================
    // Registration — call once from VivemonkecraftClient.onInitializeClient()
    // =========================================================================

    public static void register() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(HandMarkerRenderer::onRender);
    }

    // =========================================================================
    // Render callback
    // =========================================================================

    private static void onRender(WorldRenderContext ctx) {
        if (!VivemonkecraftClient.isEnabled()) return;
        if (!MovementConfig.showHandMarkers) return;
        if (shoulderMain == null || grabMain == null || shoulderOff == null || grabOff == null) return;
        if (ctx.consumers() == null) return;

        class_4597 buf   = ctx.consumers();
        class_4587         stack = ctx.matrixStack();
        class_243              cam   = ctx.camera().method_19326();

        class_4588 lines = buf.getBuffer(class_1921.method_23594());

        // Capped radius so the drawn cube always matches the EFFECTIVE grab box.
        double r = SettingCaps.handRadius();

        stack.method_22903();
        stack.method_22904(-cam.field_1352, -cam.field_1351, -cam.field_1350);

        drawArm (lines, stack, shoulderMain, grabMain, grippingMain);
        drawArm (lines, stack, shoulderOff,  grabOff,  grippingOff);
        drawCube(lines, stack, grabMain, r, grippingMain);
        drawCube(lines, stack, grabOff,  r, grippingOff);

        stack.method_22909();

        // Flush immediately so the lines are visible this frame.
        if (buf instanceof class_4597.class_4598 bs) {
            bs.method_22994(class_1921.method_23594());
        }
    }

    // =========================================================================
    // Arm drawing
    // =========================================================================

    // Draws a single straight line from shoulder socket to grab point.
    // Green when gripping a block, red when hand is free.
    private static void drawArm(class_4588 lines, class_4587 stack,
                                  class_243 shoulder, class_243 grabPoint, boolean gripping) {
        float r = gripping ? 0.0f : 1.0f;
        float g = gripping ? 1.0f : 0.0f;
        putLine(lines, stack.method_23760().method_23761(),
                shoulder.field_1352, shoulder.field_1351, shoulder.field_1350,
                grabPoint.field_1352, grabPoint.field_1351, grabPoint.field_1350,
                r, g, 0f);
    }

    // Draws a wireframe cube centred on `center` with half-size `r` (matches the
    // hand hitbox radius so the cube shows exactly what the grab detection sees).
    // Same color scheme as the arm line: green = gripping, red = free.
    private static void drawCube(class_4588 lines, class_4587 stack,
                                   class_243 centre, double r, boolean gripping) {
        float cr = gripping ? 0.0f : 1.0f;
        float cg = gripping ? 1.0f : 0.0f;
        Matrix4f m = stack.method_23760().method_23761();

        double x0 = centre.field_1352 - r, x1 = centre.field_1352 + r;
        double y0 = centre.field_1351 - r, y1 = centre.field_1351 + r;
        double z0 = centre.field_1350 - r, z1 = centre.field_1350 + r;

        // Bottom face
        putLine(lines, m, x0,y0,z0, x1,y0,z0, cr,cg,0f);
        putLine(lines, m, x1,y0,z0, x1,y0,z1, cr,cg,0f);
        putLine(lines, m, x1,y0,z1, x0,y0,z1, cr,cg,0f);
        putLine(lines, m, x0,y0,z1, x0,y0,z0, cr,cg,0f);
        // Top face
        putLine(lines, m, x0,y1,z0, x1,y1,z0, cr,cg,0f);
        putLine(lines, m, x1,y1,z0, x1,y1,z1, cr,cg,0f);
        putLine(lines, m, x1,y1,z1, x0,y1,z1, cr,cg,0f);
        putLine(lines, m, x0,y1,z1, x0,y1,z0, cr,cg,0f);
        // Vertical edges
        putLine(lines, m, x0,y0,z0, x0,y1,z0, cr,cg,0f);
        putLine(lines, m, x1,y0,z0, x1,y1,z0, cr,cg,0f);
        putLine(lines, m, x1,y0,z1, x1,y1,z1, cr,cg,0f);
        putLine(lines, m, x0,y0,z1, x0,y1,z1, cr,cg,0f);
    }

    // =========================================================================
    // Geometry helpers
    // =========================================================================

    // Emits one line segment (A→B). Normal is auto-computed from the direction.
    // In 1.21.4, setNormal takes plain floats (the Matrix 3f overload was removed).
    private static void putLine(class_4588 v, Matrix4f m,
                                  double ax, double ay, double az,
                                  double bx, double by, double bz,
                                  float r, float g, float b) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        float nx = len > 0 ? (float) (dx / len) : 1f;
        float ny = len > 0 ? (float) (dy / len) : 0f;
        float nz = len > 0 ? (float) (dz / len) : 0f;

        v.method_22918(m, (float) ax, (float) ay, (float) az)
         .method_22915(r, g, b, 1f).method_22914(nx, ny, nz);
        v.method_22918(m, (float) bx, (float) by, (float) bz)
         .method_22915(r, g, b, 1f).method_22914(nx, ny, nz);
    }

}
