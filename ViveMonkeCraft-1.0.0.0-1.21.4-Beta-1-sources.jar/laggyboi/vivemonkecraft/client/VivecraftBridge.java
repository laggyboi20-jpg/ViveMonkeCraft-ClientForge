package laggyboi.vivemonkecraft.client;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.class_243;

/**
 * Thin, dependency-free adapter over Vivecraft's VR API.
 *
 * <p>Targets <b>Vivecraft 1.2.x / QuestCraft (QCXR)</b>, which uses the internal
 * {@code org.vivecraft.client_vr.*} package (no public API).
 *
 * <p>Reflection is used so Vivecraft does NOT need to be a compile-time dependency —
 * the mod compiles without Vivecraft on the classpath and falls back gracefully to
 * {@code MISSING} if QuestCraft is not installed.
 *
 * <p>Fields accessed via reflection:
 * <ul>
 *   <li>{@code VRState.VR_RUNNING}          — static boolean, true while VR is active
 *   <li>{@code VRPlayer.get()}              — static factory → VRPlayer instance
 *   <li>{@code VRPlayer#vrdata_world_render}— VRData snapshot used for rendering
 *   <li>{@code VRData#hmd / c0 / c1}        — head / main hand / off-hand device poses
 *   <li>{@code VRDevicePose#getPosition()}  — world-space Vec3 position
 * </ul>
 */
public final class VivecraftBridge {

    // -----------------------------------------------------------------------
    // Static singleton — lets renderer classes call VivecraftBridge.isVrActive()
    // without needing their own instance.
    // -----------------------------------------------------------------------

    private static final VivecraftBridge INSTANCE = new VivecraftBridge();

    /**
     * Returns {@code true} when QuestCraft / Vivecraft 1.2.x is present AND
     * VR is currently active.  Safe to call from any thread; never throws.
     */
    public static boolean isVrActive() {
        return INSTANCE.isVRActive();
    }

    // -----------------------------------------------------------------------
    // Connection lifecycle
    // -----------------------------------------------------------------------

    private enum Link { UNTRIED, LEGACY, MISSING }
    private Link link = Link.UNTRIED;

    // -----------------------------------------------------------------------
    // Legacy API handles  (Vivecraft 1.2.x / QuestCraft)
    // -----------------------------------------------------------------------

    private Field  fVrRunning;     // VRState.VR_RUNNING  (static boolean)
    private Method mVrPlayerGet;   // VRPlayer.get()      (static → VRPlayer)
    private Field  fVrDataRender;  // VRPlayer#vrdata_world_render (VRData)
    private Field  fHmd;           // VRData#hmd          (VRDevicePose = head)
    private Field  fC0;            // VRData#c0           (VRDevicePose = main hand)
    private Field  fC1;            // VRData#c1           (VRDevicePose = off hand)
    private Method mGetPosition;   // VRDevicePose#getPosition() → Vec3

    // -----------------------------------------------------------------------
    // Public accessors
    // -----------------------------------------------------------------------

    /** @return true only when QuestCraft is present AND VR is currently active. */
    public boolean isVRActive() {
        if (tryWire() == Link.LEGACY) return legacyIsVRActive();
        return false;
    }

    /** World-space position of the right/main-hand controller, or null. */
    public class_243 getMainHandPos() {
        // While the hand-model clamp is active, the c0 pose has been swapped to the
        // SURFACE point for rendering — physics must keep seeing the real hand, so
        // return the raw position stashed by the render mixin before the swap.
        // (The GT anchor servo NEEDS surface penetration; the clamp is cosmetic.)
        if (VrHandClamp.clampMain != null && VrHandClamp.rawMain != null) {
            return VrHandClamp.rawMain;
        }
        if (tryWire() == Link.LEGACY) return legacyPosition(fC0);
        return null;
    }

    /** World-space position of the left/off-hand controller, or null. */
    public class_243 getOffHandPos() {
        if (VrHandClamp.clampOff != null && VrHandClamp.rawOff != null) {
            return VrHandClamp.rawOff;
        }
        if (tryWire() == Link.LEGACY) return legacyPosition(fC1);
        return null;
    }

    /** World-space position of the headset/eyes, or null. */
    public class_243 getHeadPos() {
        if (tryWire() == Link.LEGACY) return legacyPosition(fHmd);
        return null;
    }

    // -----------------------------------------------------------------------
    // Wire-up — idempotent after first attempt
    // -----------------------------------------------------------------------

    private Link tryWire() {
        if (link != Link.UNTRIED) return link;
        link = wireLegacy();
        return link;
    }

    // -----------------------------------------------------------------------
    // Legacy wiring (1.2.x — QuestCraft / QCXR)
    // -----------------------------------------------------------------------

    private Link wireLegacy() {
        try {
            Class<?> vrStateType      = Class.forName("org.vivecraft.client_vr.VRState");
            Class<?> vrPlayerType     = Class.forName("org.vivecraft.client_vr.gameplay.VRPlayer");
            Class<?> vrDataType       = Class.forName("org.vivecraft.client_vr.VRData");
            Class<?> vrDevicePoseType = Class.forName("org.vivecraft.client_vr.VRData$VRDevicePose");

            fVrRunning    = vrStateType.getField("VR_RUNNING");
            mVrPlayerGet  = vrPlayerType.getMethod("get");
            fVrDataRender = vrPlayerType.getField("vrdata_world_render");
            fHmd          = vrDataType.getField("hmd");
            fC0           = vrDataType.getField("c0");
            fC1           = vrDataType.getField("c1");
            mGetPosition  = vrDevicePoseType.getMethod("getPosition");

            System.out.println("[ViveMonke(Quest)Craft] QuestCraft API connected (Vivecraft 1.2.x / QCXR)");
            return Link.LEGACY;

        } catch (ClassNotFoundException e) {
            System.out.println("[ViveMonke(Quest)Craft] QuestCraft not found — mod requires QuestCraft / Vivecraft 1.2.x.");
            return Link.MISSING;
        } catch (ReflectiveOperationException e) {
            System.out.println("[ViveMonke(Quest)Craft] QuestCraft API present but unusable: " + e);
            return Link.MISSING;
        }
    }

    // -----------------------------------------------------------------------
    // Legacy data accessors
    // -----------------------------------------------------------------------

    private boolean legacyIsVRActive() {
        try {
            return fVrRunning.getBoolean(null); // static field
        } catch (ReflectiveOperationException e) {
            return false;
        }
    }

    private class_243 legacyPosition(Field devicePoseField) {
        try {
            Object vrPlayer   = mVrPlayerGet.invoke(null); // static
            if (vrPlayer == null) return null;
            Object vrData     = fVrDataRender.get(vrPlayer);
            if (vrData == null) return null;
            Object devicePose = devicePoseField.get(vrData);
            if (devicePose == null) return null;
            Object pos        = mGetPosition.invoke(devicePose);
            return (pos instanceof class_243) ? (class_243) pos : null;
        } catch (ReflectiveOperationException e) {
            return null;
        }
    }
}
