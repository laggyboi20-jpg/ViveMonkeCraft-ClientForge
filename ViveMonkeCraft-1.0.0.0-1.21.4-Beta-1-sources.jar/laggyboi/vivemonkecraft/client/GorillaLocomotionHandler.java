package laggyboi.vivemonkecraft.client;

import java.util.Arrays;
import net.minecraft.class_1324;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_746;

// =====================================================================
// GORILLA TAG LOCOMOTION HANDLER  (v5 — speed-based)
// =====================================================================
//
// Same spirit as the official Gorilla Tag (push/pull a surface, body moves the
// opposite way), but tuned for how VR + Vivecraft actually behave:
//
//   * Movement is driven by how FAST your hand is moving, not how far it is
//     pushed into a block. So a STILL hand = zero movement (you stay put, even
//     if the controller is resting in the ground), and only a real SWING moves
//     you. Gentle placement = nothing; a fast push = a launch. This is what fixes
//     the "it jumps when I set my controller down" problem.
//
//   * Per tick, for each hand touching a block:
//       swing  = how far your hand moved RELATIVE TO YOUR HEAD this tick
//       body velocity += -swing * pullStrength      (you go opposite your hand)
//     Measuring relative to the head means moving your body never feeds back into
//     the math — only your real arm motion counts.
//
//   * We SET velocity (not position) because Vivecraft drives the player position
//     from your headset and ignores direct position writes. Setting velocity to
//     the swing means: still hand -> ~0 velocity -> you hang/stay; moving hand ->
//     you move.
//
//   * The swing is measured on your RAW hand (true 1:1), while the longer "reach"
//     is only used to DETECT the grab — so reach doesn't make motion twitchy.
//
//   * We average recent swing speed; when you LET GO above velocityLimit we fling
//     you (velocity = average * jumpMultiplier, capped). That's the jump.
// =====================================================================

public class GorillaLocomotionHandler {

    // A grab counts as a FLOOR grab when the grabbed point is at least this many
    // blocks BELOW your head (i.e. you reached down to the ground). Above that it's
    // treated as a WALL grab. Your head is ~1.5 above the floor, so ~1.0 cleanly
    // separates "hand on the ground" from "hand on a wall at body height".
    private static final double FLOOR_GRIP_DEPTH = 1.0;

    // Downward slide rate (blocks/tick) of a NON-ice wall at wallStickiness 0. The
    // actual rate scales with stickiness: (1 - stick) * WALL_SLIDE_CAP, applied as an
    // offset on every grip tick so hand movement can never cancel it (anti-hover).
    // Ice walls instead slide freely under gravity (uncapped), so ice always feels
    // more slippery than any normal wall.
    private static final double WALL_SLIDE_CAP = 0.40;

    // Ticks of continuous wall grip over which the slide ramps from 0 to full rate.
    // 10 ticks = 0.5 s: quick pushes/mantles finish before the slide bites, while
    // hanging still reaches full slide fast enough that hovering stays impossible.
    private static final int WALL_SLIDE_RAMP_TICKS = 10;

    // Consecutive ticks the current low-stick wall grip has lasted (drives the ramp).
    // Reset whenever the wall grip ends (floor grip, release, teleport, desync).
    private int wallSlideTicks = 0;

    // Max horizontal distance (blocks) the VR-reported head may sit from the player
    // entity before we treat the VR data as DESYNCED (stale room origin right after a
    // Vivecraft teleport). In roomscale the head wanders < ~1 block from the body, so
    // 1.5 gives comfortable margin while still catching even short 2-block teleports.
    private static final double VR_DESYNC_DIST = 1.5;

    // Wall-stuck anti-freeze constants.
    // After WALL_STUCK_MAX ticks (2.5 s) of being stationary while wall-gripping,
    // the mod briefly forces wallStickiness to 0 so the player falls free.
    private static final int    WALL_STUCK_MAX     = 50;   // ticks (2.5 s at 20 tps)
    private static final int    DROP_RELEASE_TICKS = 10;   // ticks of forced drop (~0.5 s)
    private static final double STUCK_THRESHOLD    = 0.05; // blocks/tick to count as "moving"

    // -----------------------------------------------------------------------
    // PER-HAND STATE
    // -----------------------------------------------------------------------

    // gripping   = was this hand touching a block last tick.
    // floorGrip  = is this grab a FLOOR grab (hand on a supporting top face) rather
    //              than a WALL grab (side face). Set at first contact, and can be
    //              PROMOTED wall→floor mid-grip when the hand lands on a top face
    //              (e.g. brushing a step's side, then planting on its top to mantle).
    //              Never demoted floor→wall, so behaviour can't flip-flop.
    // prevOffset = (raw hand - head) last tick, used to measure this tick's swing.
    // wasGripping = gripping state from the previous tick (used to detect first-contact).
    private static class HandState {
        boolean gripping    = false;
        boolean floorGrip   = false;
        boolean wasGripping = false;
        class_243    prevOffset  = null;

        // GT ANCHOR MODE ONLY: the REAL hand's world position at the moment of
        // contact (arm-clamped, NO reach extension). While gripping, the body is
        // dragged each tick so the real hand returns here — Player.cs
        // "lastHandPosition". Measured on the REAL hand because the drag must see
        // surface PENETRATION (pressing into the floor = upward drag = push-off).
        class_243    anchor        = null;

        // GT ANCHOR MODE ONLY: the surface-clamped touch point at contact —
        // used only for the hand marker so the cube sits on the block face.
        class_243    anchorDisplay = null;

        // GT ANCHOR MODE ONLY: (realHand − head) at contact. Unstick measures
        // against this so it reflects PHYSICAL hand stray, unaffected by the
        // push-strength anchor receding.
        class_243    gripOffset    = null;

        void release() {
            gripping      = false;
            floorGrip     = false;
            prevOffset    = null;
            anchor        = null;
            anchorDisplay = null;
            gripOffset    = null;
            // wasGripping intentionally NOT cleared — the grab-end logic needs it this tick
        }

        void tickStart() {
            wasGripping = gripping;
        }
    }

    // -----------------------------------------------------------------------
    // STATE
    // -----------------------------------------------------------------------

    private final VivecraftBridge vr = new VivecraftBridge();
    private final HandState mainHand = new HandState();
    private final HandState offHand  = new HandState();

    // Rolling average of the intended swing velocity (blocks/tick), used for the
    // throw/jump when you let go.
    private class_243[]  swingHistory = null;
    private int     swingIndex   = 0;
    private class_243    swingAvg     = class_243.field_1353;
    private boolean wasAnyGripping = false;

    // Smoothed grip velocity used by the low-pass filter that removes VR tracking
    // noise jitter. Reset to ZERO when not gripping so each new contact starts clean.
    private class_243 smoothedGripVel = class_243.field_1353;

    // True while WE have turned the player's gravity off (during a grip), so we
    // know to turn it back on when you let go / disable the mod.
    private boolean noGravSet = false;

    // Wall-stuck anti-freeze state.
    // prevWallPos: player world-pos last tick during a wall grip (null when not gripping).
    // wallStuckTicks: ticks spent NOT moving while wall-gripping.
    // dropCooldown: ticks remaining in the forced-drop phase after getting unstuck.
    private class_243 prevWallPos    = null;
    private int  wallStuckTicks = 0;
    private int  dropCooldown   = 0;

    // Teleport detection: player's position last tick.
    // A jump of > 2 blocks in one tick is impossible from normal swinging —
    // treat it as a teleport and wipe all grip/physics state so the player
    // doesn't get welded to a surface at the new location.
    // prevTickVel = deltaMovement at the END of our previous tick — the movement we
    // EXPECTED the engine to apply. A teleport moves the player WITHOUT velocity, so
    // (actual distance moved) >> (expected velocity) is the reliable teleport signal —
    // it catches short teleports (< 2 blocks) and multi-tick dashes that a plain
    // absolute-distance threshold misses, while fast legitimate launches don't trip it
    // (their movement is fully explained by velocity).
    private class_243 prevPlayerPos  = null;
    private class_243 prevTickVel    = class_243.field_1353;
    private static final double TELEPORT_SLACK = 0.75;

    // Ticks of forced inactivity after a teleport is detected. Vivecraft can take a
    // few ticks to re-sync its room origin to the new player position; if we re-grip
    // immediately we anchor to stale hand positions and recreate the stuck state.
    private int teleportCooldown = 0;
    private static final int TELEPORT_COOLDOWN_TICKS = 5;

    // Saved step height so we can restore it when the mod turns off.
    private Double savedStepHeight = null;

    // -----------------------------------------------------------------------
    // MAIN TICK
    // -----------------------------------------------------------------------

    public void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null || client.field_1687 == null) return;
        if (!vr.isVRActive()) return;

        // ---- TELEPORT DETECTION ----
        // Compare how far the player ACTUALLY moved since last tick against how far
        // their velocity SAID they should move. A teleport (QuestCraft teleport arc)
        // relocates the player without any corresponding deltaMovement, so the actual
        // distance hugely exceeds the expected one. The old absolute > 2.0-blocks-in-
        // one-tick check missed short teleports and teleports interpolated over
        // several ticks — this velocity-mismatch check catches both.
        // TELEPORT_SLACK (0.75) absorbs movement that bypasses deltaMovement
        // legitimately: roomscale walking (~0.07 b/t), joystick locomotion (~0.2 b/t),
        // and small server position corrections.
        class_243 curPlayerPos = player.method_19538();
        if (prevPlayerPos != null
                && curPlayerPos.method_1022(prevPlayerPos)
                       > prevTickVel.method_1033() + TELEPORT_SLACK) {
            // Full reset. release() also clears floorGrip/prevOffset; we additionally
            // clear wasGripping so the post-teleport tick can't fire grab-end logic.
            mainHand.release();
            offHand.release();
            mainHand.wasGripping = false;
            offHand.wasGripping  = false;
            wasAnyGripping     = false;
            smoothedGripVel    = class_243.field_1353;
            swingHistory       = null;
            swingAvg           = class_243.field_1353;
            prevWallPos        = null;
            wallStuckTicks     = 0;
            wallSlideTicks     = 0;
            dropCooldown       = 0;

            // CRITICAL: if we were mid-grip when the teleport fired, gravity was off and
            // the player had leftover grip velocity. Without clearing both, the player
            // arrives at the new spot floating and sliding with no way to move — exactly
            // the "after teleport the hitboxes just keep sliding" bug. Re-enable gravity
            // and zero the residual momentum so normal control resumes immediately.
            if (noGravSet) { player.method_5875(false); noGravSet = false; }
            player.method_18799(class_243.field_1353);
            prevTickVel = class_243.field_1353;
            teleportCooldown = TELEPORT_COOLDOWN_TICKS;
        }
        prevPlayerPos = curPlayerPos;

        // Post-teleport settle window: do nothing for a few ticks so we can't re-grip
        // stale VR hand positions while Vivecraft re-syncs its room origin.
        if (teleportCooldown > 0) {
            teleportCooldown--;
            HandMarkerRenderer.clearState();
        VrHandClamp.clear();
            prevTickVel = player.method_18798();
            return;
        }

        class_243 rawMain = vr.getMainHandPos();
        class_243 rawOff  = vr.getOffHandPos();
        class_243 headPos = vr.getHeadPos();
        if (rawMain == null || rawOff == null || headPos == null) return;

        // ---- VR-DESYNC GUARD (Vivecraft teleport) ----
        // Vivecraft's own teleport moves the PLAYER ENTITY but its room origin (which
        // our head/hand world positions are derived from) can stay at the OLD location
        // until Vivecraft re-syncs (e.g. on joystick input). While desynced, our hands
        // are still "touching" blocks back at the old spot, so grips stay alive and
        // keep writing velocity — the "after teleport the hitboxes keep sliding and I
        // can't move" bug. Detection: the reported head should sit roughly above the
        // player's body (horizontal offset < ~1 block in roomscale). If it's further
        // than this, the VR data is stale: release everything and do NOTHING this tick
        // so vanilla / Vivecraft movement works normally until the data re-converges.
        // (Ender-pearl/server teleports snap Vivecraft's room origin immediately, which
        // is why those never desynced.)
        // Horizontal: head should be within VR_DESYNC_DIST of the body.
        // Vertical: the head normally sits ~0.3–2.5 above the feet (crouching to
        // standing). Far outside that range means the head data is from a different
        // elevation — i.e. a mostly-VERTICAL teleport (up/down a cliff) left the room
        // origin behind. Checked separately because the horizontal test can't see it.
        double headDx = headPos.field_1352 - curPlayerPos.field_1352;
        double headDy = headPos.field_1351 - curPlayerPos.field_1351;
        double headDz = headPos.field_1350 - curPlayerPos.field_1350;
        if (Math.sqrt(headDx * headDx + headDz * headDz) > VR_DESYNC_DIST
                || headDy < -0.5 || headDy > 3.5) {
            mainHand.release();
            offHand.release();
            mainHand.wasGripping = false;
            offHand.wasGripping  = false;
            wasAnyGripping  = false;
            smoothedGripVel = class_243.field_1353;
            swingHistory    = null;
            swingAvg        = class_243.field_1353;
            prevWallPos     = null;
            wallStuckTicks  = 0;
            wallSlideTicks  = 0;
            dropCooldown    = 0;
            if (noGravSet) { player.method_5875(false); noGravSet = false; }
            HandMarkerRenderer.clearState();
        VrHandClamp.clear();
            prevTickVel = player.method_18798();
            return;
        }

        // Snapshot each hand's "was gripping?" before this tick modifies it,
        // so we can detect FIRST CONTACT later.
        mainHand.tickStart();
        offHand.tickStart();

        // How fast the player is currently falling (positive = falling down).
        // Used for fall-sweep block detection and fall absorption on first grip.
        double fallSpeed = Math.max(0.0, -player.method_18798().field_1351);

        // Two versions of each hand:
        //   touch* = REACH-extended + clamped, used to DETECT the grab (so you can
        //            reach the ground while standing) and to draw the marker.
        //   swing* = RAW hand clamped to arm length, used to measure your real arm
        //            motion 1:1 (so reach doesn't make movement twitchy).
        // The raycast hit also tells us WHICH FACE was grabbed: a TOP face is a
        // supporting surface (hand plants on it, you can stand/hold), a side face is
        // a wall. This face-based split is what keeps "standing on your hands"
        // independent of wallStickiness.
        //
        // TWO rays per hand, with different jobs:
        //   HEAD ray  — clamps the GRAB POINT. The head can never be inside a block,
        //               so this ray always finds an outer face and the hand hitbox
        //               can never sink inside a wall (anti-embedding).
        //   HAND ray  — decides the FACE for floor-vs-wall classification. The hand
        //               approaches the surface directly, so it reports the face the
        //               player actually grabbed. The head ray is WRONG for this job:
        //               looking down at the ground in front of you, it arrives at a
        //               shallow diagonal and often clips a block's SIDE face — which
        //               misclassified ground grabs as wall grips and made hands slide
        //               on the ground / fail to mantle 1-block steps.
        //   If the hand ray misses (hand already inside a block), fall back to the
        //   head ray's face — an embedded hand therefore still counts as a WALL grab,
        //   which keeps the old hover-inside-the-block exploit impossible.
        class_243 targetMain = clampArm(extendReach(rawMain, headPos), headPos);
        class_243 targetOff  = clampArm(extendReach(rawOff,  headPos), headPos);
        // Clamp-ray ORIGIN: the TORSO (midway between feet and head), NOT the head.
        // In 1-block-tall areas the head presses against the ceiling block — a
        // head-origin ray then starts inside that block and instantly "hits" it,
        // sticking the hands to the ceiling. The torso midpoint stays inside the
        // body, which is never inside blocks, so the clamp still prevents grabbing
        // through walls without the ceiling false-grab.
        class_243 castOrigin = new class_243(headPos.field_1352, (headPos.field_1351 + player.method_23318()) * 0.5, headPos.field_1350);
        class_3965 hitMain     = raycastGrab(client, player, castOrigin, targetMain);
        class_3965 hitOff      = raycastGrab(client, player, castOrigin, targetOff);
        class_3965 handHitMain = raycastGrab(client, player, rawMain, targetMain);
        class_3965 handHitOff  = raycastGrab(client, player, rawOff,  targetOff);
        class_243 touchMain = (hitMain != null) ? hitMain.method_17784()
                             : (handHitMain != null) ? handHitMain.method_17784() : targetMain;
        class_243 touchOff  = (hitOff  != null) ? hitOff.method_17784()
                             : (handHitOff  != null) ? handHitOff.method_17784()  : targetOff;
        boolean topFaceMain = (handHitMain != null)
                ? handHitMain.method_17780() == class_2350.field_11036
                : hitMain != null && hitMain.method_17780() == class_2350.field_11036;
        boolean topFaceOff  = (handHitOff != null)
                ? handHitOff.method_17780() == class_2350.field_11036
                : hitOff != null && hitOff.method_17780() == class_2350.field_11036;
        class_243 swingMain = clampArm(rawMain, headPos);
        class_243 swingOff  = clampArm(rawOff,  headPos);

        // ---- STEP ASSIST ----
        // Suppress raised step height when a barrier block is immediately adjacent —
        // barrier blocks are server admin boundaries that players shouldn't walk over.
        // Also suppress when touching ice (ice push-off path handles movement itself).
        boolean barrierAdjacent = hasBarrierInAABB(client.field_1687,
                player.method_5829().method_1009(0.12, 0, 0.12));
        if (MovementConfig.stepAssist && !barrierAdjacent) {
            applyStepHeight(player, MovementConfig.stepHeight);
        } else {
            restoreStepHeight(player);
        }

        ensureSwingHistory();

        // ---- PHYSICS MODE DISPATCH ----
        // gtPhysics=true  → faithful Gorilla Tag anchor physics (Player.cs port)
        // gtPhysics=false → the original speed-based model below
        // (The speed-based block keeps its original indentation to keep its diff
        // history readable.)
        if (MovementConfig.gtPhysics) {
            applyGtPhysics(client, player, touchMain, touchOff,
                           swingMain, swingOff, headPos,
                           topFaceMain, topFaceOff, fallSpeed);
        } else {

        // ---- PER-HAND SWING -> VELOCITY ----
        class_243 mainVel = processHand(client, mainHand, touchMain, swingMain, headPos, fallSpeed, topFaceMain);
        class_243 offVel  = processHand(client, offHand,  touchOff,  swingOff,  headPos, fallSpeed, topFaceOff);

        // ---- FALL ABSORPTION: first floor contact while falling fast zeroes downward vel ----
        // When you extend your hand toward the ground during a fall, the first tick
        // your hand actually touches a block should stop your fall — otherwise you'd
        // bounce/clip through because the raw impact velocity is still huge.
        boolean newMainFloor = (!mainHand.wasGripping && mainHand.gripping && mainHand.floorGrip);
        boolean newOffFloor  = (!offHand.wasGripping  && offHand.gripping  && offHand.floorGrip);
        if ((newMainFloor || newOffFloor) && fallSpeed > 0.1) {
            class_243 v = player.method_18798();
            player.method_18800(v.field_1352, 0.0, v.field_1350); // kill downward velocity on contact
        }

        // ---- PER-HAND ICE-WALL DETECTION ----
        // Ice is slippery on ALL faces. Probe ±0.06 around each grab point so we catch
        // the ice block regardless of which face the grab landed on. A hand counts as
        // being on an ICE WALL when it grips a non-floor (vertical) ice surface.
        // These multipliers are reused further down for the floor/ground ice handling,
        // so we compute them once here.
        double  mainGrabMult = mainHand.gripping ? iceNearMultiplier(client, touchMain) : 0.0;
        double  offGrabMult  = offHand.gripping  ? iceNearMultiplier(client, touchOff)  : 0.0;
        boolean mainIceWall  = mainHand.gripping && !mainHand.floorGrip && mainGrabMult > 0.0;
        boolean offIceWall   = offHand.gripping  && !offHand.floorGrip && offGrabMult  > 0.0;

        // ---- ICE WALL: DISABLE THE OTHER HAND ----
        // While one hand is on an ice wall you are committed to the slide / push-off:
        // the other hand's grab is switched off so you can't arrest the slide by grabbing
        // a second block. The main hand wins if both land on ice the same tick.
        // Ice walls are no longer "pushed off" via a one-tick release impulse (that
        // fought with the throw-on-release path and lost most of the gesture) Instead
        // an ice-wall grip now PERSISTS like a normal grip but with gravity left on and
        // no cling (see the wall-grip branch below) — so a sustained push builds real
        // momentum that the existing throw-on-release then launches you.
        if (mainIceWall && offHand.gripping) {
            offHand.release();
            offVel      = class_243.field_1353;
            offGrabMult = 0.0;
            offIceWall  = false;
        } else if (offIceWall && mainHand.gripping) {
            mainHand.release();
            mainVel      = class_243.field_1353;
            mainGrabMult = 0.0;
            mainIceWall  = false;
        }

        int gripCount = (mainHand.gripping ? 1 : 0) + (offHand.gripping ? 1 : 0);
        boolean anyGrip = gripCount > 0;

        // Two hands at once -> average (so two hands don't double your speed).
        class_243 vel = (gripCount == 2) ? mainVel.method_1019(offVel).method_1021(0.5) : mainVel.method_1019(offVel);

        // Ignore micro-movements (controller jitter) so a resting hand truly rests.
        if (vel.method_1033() < MovementConfig.minImpulse) vel = class_243.field_1353;

        // Cap so a tracking glitch can't fling you.
        // Also honours the server's maxJumpSpeed limit if one is set.
        double maxSpd = ServerLimits.maxJumpSpeed(MovementConfig.maxJumpSpeed);
        if (vel.method_1033() > maxSpd) {
            vel = vel.method_1029().method_1021(maxSpd);
        }

        // Feed this tick's swing velocity into the rolling average (for the throw).
        // NOTE: we use the RAW vel here (before smoothing) so the throw reads the real
        // intended swing speed and not a noise-averaged-down version.
        storeSwing(anyGrip ? vel : class_243.field_1353);

        // ---- GRIP SMOOTHING (low-pass filter on locomotion velocity) ----
        // VR controllers have ~1-2 mm of tracking noise even when held still.
        // Multiplied by pullStrength (default 2.0) this becomes tiny oscillating
        // velocity spikes every tick that are very visible at VR framerates (90fps).
        // An exponential moving average kills that high-frequency noise:
        // smoothedVel = lerp(smoothedVel, rawVel, 1 - gripSmoothing)
        // gripSmoothing = 0.0 → instant response (raw, old behaviour)
        // gripSmoothing = 0.5 → each tick is 50% new + 50% last tick (default, ~67%
        //                       attenuation of tick-rate noise) with ~5 tick rise-time
        // gripSmoothing = 0.8 → heavy smoothing, good for sickness-prone players but
        //                       slightly lazy response
        // When NOT gripping, reset to ZERO so the filter starts clean next contact.
        double smoothing = MovementConfig.gripSmoothing;
        if (anyGrip && smoothing > 0.0) {
            double alpha = 1.0 - Math.min(0.95, smoothing);
            smoothedGripVel = new class_243(
                smoothedGripVel.field_1352 + (vel.field_1352 - smoothedGripVel.field_1352) * alpha,
                smoothedGripVel.field_1351 + (vel.field_1351 - smoothedGripVel.field_1351) * alpha,
                smoothedGripVel.field_1350 + (vel.field_1350 - smoothedGripVel.field_1350) * alpha
            );
            vel = smoothedGripVel;
        } else {
            smoothedGripVel = class_243.field_1353;
        }

        // ---- ICE SURFACE DETECTION ----
        // Feet: check the block directly under the player.
        // All ice variants share one speed-cap multiplier (×0.4 — see
        // iceBlockMultiplier), kept low for Quest performance.
        // 0.1 below minY rather than blockPosition().below() so it works correctly
        // at any sub-block Y position (e.g. standing partway off a slab edge).
        class_2338   iceFeetPos   = class_2338.method_49637(
                player.method_23317(), player.method_5829().field_1322 - 0.1, player.method_23321());
        double     feetIceMult  = iceBlockMultiplier(client, iceFeetPos);
        boolean    onIce        = feetIceMult > 0.0;
        // iceSpeedCap > 0 signals "feet on ice"; 0 means normal surface.
        double     effMaxSpd    = ServerLimits.maxJumpSpeed(MovementConfig.maxJumpSpeed);
        double     iceSpeedCap  = onIce ? effMaxSpd * feetIceMult : 0.0;

        // ---- GRAB-POINT ICE (reuses the per-hand multipliers computed up top) ----
        double  grabIceMult     = Math.max(mainGrabMult, offGrabMult);
        boolean grabOnIce       = grabIceMult > 0.0;
        double  grabIceSpeedCap = grabOnIce ? effMaxSpd * grabIceMult : 0.0;

        // ---- APPLY ----
        if (anyGrip) {
            // Is at least one gripping hand on a WALL (vertical surface) rather than the
            // floor? Wall grips use wallStickiness (vertical cling / slide-down); a grip
            // where every touching hand is on the floor uses floorStickiness (horizontal
            // slide). Mixed grips (one wall, one floor) are treated as a wall grip
            // because you're effectively climbing.
            boolean wallGrip = (mainHand.gripping && !mainHand.floorGrip)
                            || (offHand.gripping  && !offHand.floorGrip);

            // EXPERIMENTAL OPTION (iceFloorWallLogic): route ICE FLOOR grabs through
            // the ice-WALL branch instead of the floor branch — gravity stays on,
            // no anchor glue, pure push-off momentum, exactly like an ice wall.
            // One line by design so it's trivial to remove after testing.
            if (MovementConfig.iceFloorWallLogic && grabOnIce) wallGrip = true;

            if (wallGrip) {

                // ---- WALL-STUCK ANTI-FREEZE ----
                // If the player hasn't moved for WALL_STUCK_MAX ticks (2.5 s) while
                // wall-gripping, briefly force wallStickiness to 0 so they drop free
                // and can find a new grip point instead of being welded to the wall.
                class_243 curPos = player.method_19538();
                if (prevWallPos != null && curPos.method_1022(prevWallPos) < STUCK_THRESHOLD) {
                    wallStuckTicks++;
                } else {
                    wallStuckTicks = 0;
                }
                prevWallPos = curPos;
                if (wallStuckTicks >= WALL_STUCK_MAX) {
                    dropCooldown   = DROP_RELEASE_TICKS;
                    wallStuckTicks = 0;
                }
                if (dropCooldown > 0) dropCooldown--;

                // ---- WALL GRIP: vertical behaviour, controlled by wallStickiness ----
                //   stick >= 1.0 -> FULL CLING: hang in place, gravity OFF. Upward swing climbs.
                //   0 < stick < 1 -> SLIDE: gravity ON, you fall but the slide is damped
                //                    by stickiness (higher stick = slower slide). Upward
                //                    swing still climbs a normal wall.
                //   stick == 0    -> SLIDE at full gravity (no cling at all).
                //
                // Ice walls force stick to 0 (slippery on every face) AND ignore the
                // upward climb push, so ice can be pushed off / slid on but never climbed.
                // dropCooldown forces stick to 0 while the anti-freeze drop is active.
                //
                // KEY FIX (walls didn't slide at low stickiness): the SLIDE branch must
                // NOT overwrite the gravity-accumulated downward velocity every tick.
                // The original code honoured ANY upward swing (vel.y > 0) as a "climb" —
                // but VR controller jitter makes vel.y flicker just above 0 almost every
                // tick, so the fall kept being cancelled and the player stuck in place.
                // Fix: only a DELIBERATE upward swing (vel.y above CLIMB_THRESHOLD, well
                // above jitter amplitude) counts as a climb/push; anything below it is
                // treated as a still hand and the gravity slide proceeds. Ice walls
                // ignore the climb entirely (slippery — can be pushed off, never climbed).
                // Note: hands planted on TOP faces never reach this branch any more —
                // they're classified as floor grips (see processHand), which is what
                // makes standing on blocks work at any wallStickiness value.
                boolean iceWall = grabOnIce;
                double  stick   = (iceWall || dropCooldown > 0) ? 0.0 : MovementConfig.wallStickiness;

                if (stick >= 1.0) {
                    // Full cling — hang in place, gravity off. Upward swing climbs.
                    double finalY = (vel.field_1351 > 0) ? vel.field_1351 : 0.0;
                    player.method_18800(vel.field_1352, finalY, vel.field_1350);
                    if (!noGravSet) { player.method_5875(true); noGravSet = true; }
                } else if (iceWall) {
                    // Ice wall — free gravity slide, uncapped, never climbable.
                    if (noGravSet) { player.method_5875(false); noGravSet = false; }
                    double down = Math.min(0.0, player.method_18798().field_1351);
                    // iceFloorWallLogic routes ICE FLOOR grabs through this branch —
                    // but on a floor you must be able to push UPWARD off the ice.
                    // Honour a deliberate upward swing (above jitter, ~0.03 b/t);
                    // sustained climbing still can't happen (each push needs a
                    // fresh re-grab and gravity is on the whole time).
                    double ny = (MovementConfig.iceFloorWallLogic && vel.field_1351 > 0.03)
                            ? vel.field_1351 : down;
                    player.method_18800(vel.field_1352, ny, vel.field_1350);
                } else {
                    // LOW-STICK WALL — the swing drives the body 1:1 with a downward
                    // slide superimposed on top:
                    //     y = swing Y - (1 - stick) * WALL_SLIDE_CAP * ramp
                    // The slide RAMPS UP over WALL_SLIDE_RAMP_TICKS of continuous wall
                    // grip instead of hitting at full rate instantly:
                    //   * quick pushes / 1-block mantles happen in the first few ticks,
                    //     while the slide is still near zero — so they keep the snappy
                    //     feel of the old build instead of being yanked down mid-push
                    //   * hanging still ramps to the full rate within ~½ s, so one-hand
                    //     hovering is still impossible (the anti-hover fix holds);
                    //     jiggling can't cancel it because the slide ignores hand motion
                    //   * releasing and re-grabbing resets the ramp — intentional, per
                    //     the bug note: a fresh (red→green) grab may stick again briefly
                    // While standing ON THE GROUND the slide never pushes downward —
                    // that only drilled the player's legs into the floor.
                    if (!noGravSet) { player.method_5875(true); noGravSet = true; }
                    wallSlideTicks++;
                    double ramp   = Math.min(1.0, wallSlideTicks / (double) WALL_SLIDE_RAMP_TICKS);
                    double slideY = -(1.0 - stick) * WALL_SLIDE_CAP * ramp;
                    double ny     = vel.field_1351 + slideY;
                    if (player.method_24828() && ny < 0) ny = 0;
                    player.method_18800(vel.field_1352, ny, vel.field_1350);
                }

            } else {
                // Floor grip: not on a wall, so reset the wall-stuck timer and slide ramp.
                prevWallPos    = null;
                wallStuckTicks = 0;
                wallSlideTicks = 0;

                // ---- FLOOR GRIP: horizontal cling ----
                // Gravity stays OFF (planted hand holds you up).
                //
                // How much existing momentum is KEPT each tick (= 1 - stickiness):
                //   floorStickiness 1.0 → keep=0   → stop dead on contact (default)
                //   floorStickiness 0.5 → keep=0.5 → glide a bit after each push
                //   floorStickiness 0.0 → keep=1.0 → full momentum retained (ice-like)
                //
                // Ice OVERRIDES floorStickiness to keep=1.0 so hands don't act as
                // glue on a slippery surface. The speed cap switches to the ice cap
                // (maxJumpSpeed × 0.4) so ice stays controllable on Quest hardware.
                if (!noGravSet) { player.method_5875(true); noGravSet = true; }
                // Merge feet-ice and grab-ice: ice is slippery from any contact face.
                double keep = (onIce || grabOnIce) ? 1.0 : 1.0 - MovementConfig.floorStickiness;
                keep = Math.max(0.0, Math.min(1.0, keep));
                class_243   cur      = player.method_18798();
                double nx       = vel.field_1352 + cur.field_1352 * keep;
                double nz       = vel.field_1350 + cur.field_1350 * keep;
                // Use the higher speed cap from either feet or grab.
                double effectiveIceSpeedCap = Math.max(iceSpeedCap, grabIceSpeedCap);
                double speedCap = (effectiveIceSpeedCap > 0.0) ? effectiveIceSpeedCap : effMaxSpd;
                double hl       = Math.sqrt(nx * nx + nz * nz);
                if (hl > speedCap) {
                    double f = speedCap / hl;
                    nx *= f; nz *= f;
                }
                player.method_18800(nx, vel.field_1351, nz);
            }

            // WALL-CLIP GUARD: after all grip logic has set deltaMovement, sweep the
            // player's AABB along each velocity axis against block geometry. Any axis
            // that would enter a solid block this tick is zeroed, so the player stops
            // at the wall face instead of clipping through it.
            // expandTowards() gives a swept AABB covering the full movement path so
            // even thin (1-block) walls are caught at high speeds.
            class_243 clampIn = player.method_18798();
            class_243 clampOut = clampToBlocks(client, player, clampIn);
            if (clampOut != clampIn) player.method_18799(clampOut);

        } else {
            // Not gripping: gravity back on. Reset wall-stuck state and the slide
            // ramp so a fresh wall contact starts both timers from zero.
            prevWallPos    = null;
            wallStuckTicks = 0;
            wallSlideTicks = 0;
            if (dropCooldown > 0) dropCooldown--;
            if (noGravSet) { player.method_5875(false); noGravSet = false; }

            // GRAVITY MULTIPLIER: counteract a fraction of vanilla gravity each tick.
            // Vanilla adds ~0.08 downward per tick. We cancel (1-g)*0.08 upward,
            // leaving only g*0.08 net gravity. We only do this in the air (onGround
            // handles stopping the fall naturally) and only when g < 1.
            double g = MovementConfig.gravityMultiplier;
            if (g < 1.0 && !player.method_24828()) {
                double counterGrav = 0.08 * (1.0 - g);
                class_243 v = player.method_18798();
                player.method_18800(v.field_1352, v.field_1351 + counterGrav, v.field_1350);
            }

            // THROW / JUMP: the moment you let go after swinging fast, fling yourself.
            boolean threw = false;
            if (wasAnyGripping && swingAvg.method_1033() > MovementConfig.velocityLimit) {
                class_243 throwVel = swingAvg.method_1021(MovementConfig.jumpMultiplier);
                if (throwVel.method_1033() > effMaxSpd) {
                    throwVel = throwVel.method_1029().method_1021(effMaxSpd);
                }
                player.method_18799(throwVel);
                threw = true;
            }

            // GROUND FRICTION: damp horizontal speed when standing on the ground.
            //
            // Ice state was already sampled above (shared with floor-grip path).
            //   Any ice          → zero friction, speed cap ×0.4 (capped below normal)
            //   Normal surface   → groundFriction × floorStickiness,
            //     floorStickiness 1.0 = full friction (stops fast)
            //     floorStickiness 0.0 = frictionless (same feel as ice)
            if (!threw && player.method_24828()) {
                double effectiveFriction = onIce
                        ? 1.0   // zero friction — no damping at all
                        : Math.max(0.0, Math.min(1.0,
                              MovementConfig.groundFriction * MovementConfig.floorStickiness));

                if (effectiveFriction < 1.0) {
                    class_243 v = player.method_18798();
                    player.method_18800(v.field_1352 * effectiveFriction, v.field_1351, v.field_1350 * effectiveFriction);
                }

                // Ice speed cap (horizontal only — vertical fall is unaffected).
                if (iceSpeedCap > 0.0) {
                    class_243 v = player.method_18798();
                    double hs = Math.sqrt(v.field_1352 * v.field_1352 + v.field_1350 * v.field_1350);
                    if (hs > iceSpeedCap) {
                        double sc = iceSpeedCap / hs;
                        player.method_18800(v.field_1352 * sc, v.field_1351, v.field_1350 * sc);
                    }
                }
            }

            // AIR FRICTION COUNTER: partially cancel vanilla horizontal air drag while
            // airborne and not gripping. Vanilla multiplies horizontal velocity by ~0.91
            // per tick. We compensate by multiplying by 0.91^(af-1), so:
            //   af=1.0  → compensate=0.91^0 =1.0    (no change — full vanilla drag)
            //   af=0.5  → compensate=0.91^(-0.5)≈1.048  (partial cancel — longer throws)
            //   af=0.0  → compensate=0.91^(-1) ≈1.099  (full cancel — throws carry forever)
            double af = MovementConfig.airFriction;
            if (af < 1.0 && !player.method_24828()) {
                double compensate = Math.pow(0.91, af - 1.0);
                class_243 v = player.method_18798();
                player.method_18800(v.field_1352 * compensate, v.field_1351, v.field_1350 * compensate);
            }

            // LAUNCH STEP BOOST: Minecraft's step-height attribute only works when the
            // player is on the ground. When airborne and launched toward a block side, the
            // normal collision resolution kills horizontal momentum instead of stepping up.
            // This detects that situation each tick and adds enough upward velocity to
            // ride over the block cleanly, preserving horizontal momentum.
            // Skip the launch step boost on ice (the push-off path handles movement)
            // and skip it entirely if the blocking a block ahead is a barrier.
            if (MovementConfig.stepAssist && !player.method_24828()
                    && !onIce && !grabOnIce) {
                applyLaunchStepBoost(client, player);
            }
        }
        wasAnyGripping = anyGrip;

        } // end of speed-based physics (gtPhysics=false)

        // ---- HAND MARKERS ----
        // Push this tick's hand positions to HandMarkerRenderer so it can draw them
        // every render frame (not just every game tick — smoother in VR).

        // Shoulder joints: anchored to the player model's arm sockets.
        //
        // In Minecraft, right direction = (cos(yaw), 0, sin(yaw)).
        //   yaw=0   → facing South, right = East  (+X) ✓
        //   yaw=90  → facing West,  right = South (+Z) ✓
        //
        // Vivecraft convention: c0 = right/main hand, c1 = left/offhand.
        // sw = lateral shoulder offset from spine (blocks); sd = drop below head centre.
        // Vanilla body is 0.6 wide → half-width = 0.30, head-to-shoulder ≈ 0.24.
        float  yawRad = (float) Math.toRadians(player.method_36454());
        double rightX = Math.cos(yawRad);
        double rightZ = Math.sin(yawRad);
        double sw = 0.30;   // vanilla body half-width
        double sd = 0.24;   // vanilla head-to-shoulder drop

        // In QuestCraft the "main" controller is the LEFT hand, so its shoulder
        // socket is on the LEFT side (negative right direction) and vice versa.
        HandMarkerRenderer.shoulderMain = new class_243(
            headPos.field_1352 - rightX * sw,
            headPos.field_1351 - sd,
            headPos.field_1350 - rightZ * sw
        );
        HandMarkerRenderer.shoulderOff  = new class_243(
            headPos.field_1352 + rightX * sw,
            headPos.field_1351 - sd,
            headPos.field_1350 + rightZ * sw
        );

        // (In GT anchor mode a gripping hand displays at its planted surface point.)
        HandMarkerRenderer.grabMain     = (mainHand.anchorDisplay != null) ? mainHand.anchorDisplay : touchMain;
        HandMarkerRenderer.grippingMain = mainHand.gripping;
        HandMarkerRenderer.grabOff      = (offHand.anchorDisplay != null) ? offHand.anchorDisplay : touchOff;

        // Publish the same surface points to the VR hand-model clamp (render-frame
        // mixin) so Vivecraft's hand MODELS plant on the block face while gripping
        // instead of sinking inside — null when free or when the feature is off.
        if (MovementConfig.clampHandModels) {
            VrHandClamp.clampMain = mainHand.gripping ? HandMarkerRenderer.grabMain : null;
            VrHandClamp.clampOff  = offHand.gripping  ? HandMarkerRenderer.grabOff  : null;
        } else {
            VrHandClamp.clear();
        }
        HandMarkerRenderer.grippingOff  = offHand.gripping;

        // Record the velocity we are handing to the engine this tick — next tick's
        // teleport detection compares actual movement against this expectation.
        prevTickVel = player.method_18798();
    }

    // Called when the mod is toggled off: drop grips, restore attributes, reset tracking.
    public void onDisable(class_310 client) {
        mainHand.release();
        offHand.release();
        swingHistory = null;
        swingAvg = class_243.field_1353;
        wasAnyGripping = false;
        HandMarkerRenderer.clearState();
        VrHandClamp.clear();
        if (client != null && client.field_1724 != null) {
            restoreStepHeight(client.field_1724);
            // Make sure we don't leave the player floating with gravity off.
            if (noGravSet) { client.field_1724.method_5875(false); noGravSet = false; }
        }
        noGravSet = false;
    }

    // Called every tick a GUI screen is open (inventory, chat, settings, ...):
    // gorilla locomotion must not move the player while they're in a menu.
    // Drops all grips and restores gravity — same reset as the teleport guard —
    // and primes the trackers so closing the GUI resumes cleanly without
    // tripping the teleport detector on the accumulated position gap.
    public void onGuiPause(class_310 client) {
        mainHand.release();
        offHand.release();
        mainHand.wasGripping = false;
        offHand.wasGripping  = false;
        wasAnyGripping  = false;
        smoothedGripVel = class_243.field_1353;
        swingHistory    = null;
        swingAvg        = class_243.field_1353;
        prevWallPos     = null;
        wallStuckTicks  = 0;
        wallSlideTicks  = 0;
        dropCooldown    = 0;
        HandMarkerRenderer.clearState();
        VrHandClamp.clear();
        if (client.field_1724 != null) {
            if (noGravSet) { client.field_1724.method_5875(false); noGravSet = false; }
            prevTickVel = client.field_1724.method_18798();
        }
        prevPlayerPos = null;   // skip one teleport check when the GUI closes
    }

    // =========================================================================
    // GT ANCHOR PHYSICS  (MovementConfig.gtPhysics = true)
    // =========================================================================
    //
    // Faithful port of the official GorillaLocomotion Player.cs algorithm:
    //   * On contact a hand ANCHORS at the REAL hand's world position. Each tick
    //     the body is dragged by (anchor − currentRealHand) × dragGain so the
    //     hand stays planted — position-based 1:1.
    //   * gtPushStrength: the anchor RECEDES by (X−1)× the head-relative hand
    //     swing, so body travel = hand swing × X (X=1 is authentic GT).
    //   * Two anchored hands average their drags. Ice lets the anchor chase the
    //     hand (gtIceSlip) — push off, never hold. A hand straying further than
    //     gtUnstickDistance (physically, head-relative) lets go.
    //   * THE THROW: commanded velocity is averaged; on release the player is
    //     flung at avg × jumpMultiplier capped at maxJumpSpeed.

    private void applyGtPhysics(class_310 client, class_746 player,
                                 class_243 touchMain, class_243 touchOff,
                                 class_243 realMain,  class_243 realOff, class_243 headPos,
                                 boolean topFaceMain, boolean topFaceOff,
                                 double fallSpeed) {

        double effMaxSpd = SettingCaps.maxJumpSpeed();

        class_243 dragMain = gtProcessHand(client, mainHand, touchMain, realMain, headPos, topFaceMain, fallSpeed);
        class_243 dragOff  = gtProcessHand(client, offHand,  touchOff,  realOff,  headPos, topFaceOff,  fallSpeed);

        int gripCount   = (mainHand.gripping ? 1 : 0) + (offHand.gripping ? 1 : 0);
        boolean anyGrip = gripCount > 0;

        // Both hands anchored → average so two hands don't double the drag.
        class_243 move = (gripCount == 2) ? dragMain.method_1019(dragOff).method_1021(0.5)
                                     : dragMain.method_1019(dragOff);

        // Jitter floor and tracking-glitch cap (same guards as speed mode).
        if (move.method_1033() < MovementConfig.minImpulse) move = class_243.field_1353;
        if (move.method_1033() > effMaxSpd) move = move.method_1029().method_1021(effMaxSpd);

        // PROPORTIONAL SERVO GAIN — deliberately NOT an EMA filter (an EMA keeps
        // memory of old corrections and re-applies them after the hand reached its
        // anchor = the suck-in/rebound oscillation). Must stay below 1.0: Vivecraft
        // reports hand positions ~1 tick late, so full-strength corrections resonate.
        class_243 vel = move.method_1021(Math.max(0.05, Math.min(0.95, MovementConfig.gtDragGain)));

        // Feed the throw average with the velocity we actually command.
        storeSwing(anyGrip ? vel : class_243.field_1353);

        if (anyGrip) {
            // Gripping: gravity off (the anchor holds you), body dragged to anchor.
            if (!noGravSet) { player.method_5875(true); noGravSet = true; }

            // Wall-clip guard — zero any axis that would enter solid geometry.
            player.method_18799(clampToBlocks(client, player, vel));

        } else {
            smoothedGripVel = class_243.field_1353;
            if (noGravSet) { player.method_5875(false); noGravSet = false; }

            // Gravity multiplier (identical to speed mode).
            double g = SettingCaps.gravityMultiplier();
            if (g < 1.0 && !player.method_24828()) {
                double counterGrav = 0.08 * (1.0 - g);
                class_243 v = player.method_18798();
                player.method_18800(v.field_1352, v.field_1351 + counterGrav, v.field_1350);
            }

            // THE THROW — Player.cs: velocity = jumpMultiplier × avg, capped.
            boolean threw = false;
            if (wasAnyGripping && swingAvg.method_1033() > MovementConfig.velocityLimit) {
                class_243 throwVel = swingAvg.method_1021(SettingCaps.jumpMultiplier());
                if (throwVel.method_1033() > effMaxSpd) {
                    throwVel = throwVel.method_1029().method_1021(effMaxSpd);
                }
                player.method_18799(throwVel);
                threw = true;
            }

            // Ground friction (ice = frictionless, capped at the ice speed cap).
            class_2338 feetPos = class_2338.method_49637(
                    player.method_23317(), player.method_5829().field_1322 - 0.1, player.method_23321());
            double   feetIce = iceBlockMultiplier(client, feetPos);
            boolean  onIce   = feetIce > 0.0;
            if (!threw && player.method_24828()) {
                double effectiveFriction = onIce
                        ? 1.0
                        : Math.max(0.0, Math.min(1.0,
                              MovementConfig.groundFriction * MovementConfig.floorStickiness));
                if (effectiveFriction < 1.0) {
                    class_243 v = player.method_18798();
                    player.method_18800(v.field_1352 * effectiveFriction, v.field_1351, v.field_1350 * effectiveFriction);
                }
                if (onIce) {
                    double iceCap = effMaxSpd * feetIce;
                    class_243 v  = player.method_18798();
                    double hs = Math.sqrt(v.field_1352 * v.field_1352 + v.field_1350 * v.field_1350);
                    if (hs > iceCap) {
                        double sc = iceCap / hs;
                        player.method_18800(v.field_1352 * sc, v.field_1351, v.field_1350 * sc);
                    }
                }
            }

            // Air friction compensation (identical to speed mode).
            double af = SettingCaps.airFriction();
            if (af < 1.0 && !player.method_24828()) {
                double compensate = Math.pow(0.91, af - 1.0);
                class_243 v = player.method_18798();
                player.method_18800(v.field_1352 * compensate, v.field_1351, v.field_1350 * compensate);
            }

            // Step assist while airborne.
            if (MovementConfig.stepAssist && !player.method_24828() && !onIce) {
                applyLaunchStepBoost(client, player);
            }
        }
        wasAnyGripping = anyGrip;
    }

    // GT per-hand processing: anchor management + drag computation.
    //   touchHand — surface-clamped, reach-extended point: detects the grab and
    //               places the visual marker (never used for the drag).
    //   realHand  — the real controller position, arm-clamped only: the servo
    //               measures drag = anchor − realHand, so pressing INTO a surface
    //               produces real penetration depth and therefore real push-off.
    private class_243 gtProcessHand(class_310 client, HandState state,
                                class_243 touchHand, class_243 realHand, class_243 headPos,
                                boolean topFace, double fallSpeed) {

        boolean touching = isTouchingBlockFallSweep(client, touchHand, fallSpeed);
        if (!touching) {
            state.release();
            return class_243.field_1353;
        }

        if (!state.gripping) {
            // First contact: plant the anchor at the REAL hand, no movement yet.
            // (The zero drag this tick stops a fall dead on hand-plant, matching
            // GT's velocity-zero on touch.)
            state.gripping      = true;
            state.floorGrip     = topFace;
            state.anchor        = realHand;
            state.anchorDisplay = touchHand;
            state.prevOffset    = realHand.method_1020(headPos);
            state.gripOffset    = state.prevOffset;
            return class_243.field_1353;
        }

        // PUSH STRENGTH amplification: move the anchor AWAY from the hand by
        // (X − 1) of this tick's head-relative hand swing, so the body ends up
        // travelling X× the swing. X = 1.0 leaves the anchor fixed = authentic GT.
        class_243 offset = realHand.method_1020(headPos);
        double push = SettingCaps.gtPushStrength();
        if (push != 1.0) {
            class_243 handSwing = offset.method_1020(state.prevOffset);
            state.anchor = state.anchor.method_1020(handSwing.method_1021(push - 1.0));
        }
        state.prevOffset = offset;

        // Drag the body so the REAL hand returns to its anchor. A still hand sits
        // exactly at its anchor → zero drag → no movement (no phantom suction).
        class_243 drag = state.anchor.method_1020(realHand);

        // Surface slip (GT Surface.slipPercentage): on ice the anchor chases the
        // hand — push-offs work, hanging on doesn't.
        double slip = (iceNearMultiplier(client, touchHand) > 0.0)
                ? Math.max(0.0, Math.min(1.0, MovementConfig.gtIceSlip)) : 0.0;
        if (slip > 0.0) {
            state.anchor = state.anchor.method_1020(drag.method_1021(slip));
            drag = drag.method_1021(1.0 - slip);
        }

        // Unstick (Player.cs unStickDistance): release when the hand has PHYSICALLY
        // strayed too far from where it grabbed (head-relative, so push-strength
        // anchor receding doesn't trigger it early).
        if (offset.method_1020(state.gripOffset).method_1033() > MovementConfig.gtUnstickDistance) {
            state.release();
            return class_243.field_1353;
        }

        return drag;
    }

    // -----------------------------------------------------------------------
    // PER-HAND SWING  — returns the velocity (blocks/tick) this hand contributes
    // -----------------------------------------------------------------------

    private class_243 processHand(class_310 client, HandState state,
                              class_243 touchHand, class_243 swingHand, class_243 headPos,
                              double fallSpeed, boolean topFace) {

        // Use the fall-sweep version: when falling fast the extended-reach endpoint can
        // skip past thin floors in one tick. Extending the detection AABB upward by the
        // fall speed catches any block the hand passed through this tick.
        boolean touching = isTouchingBlockFallSweep(client, touchHand, fallSpeed);
        if (!touching) {
            state.release();
            return class_243.field_1353;
        }

        // Measure swing from swingHand (real hand, clamped to arm length) relative to
        // the head. We ALWAYS use swingHand here — never touchHand — so the reference is
        // consistent between the init tick and every subsequent tick. Using touchHand
        // (which is extended 2.5× by reach) on init but swingHand afterwards created a
        // phantom delta on the very first movement tick ("reach-gap suction"). Rebound
        // from punches (swingHand briefly inside a block) is handled by clampToBlocks.
        class_243 offset = swingHand.method_1020(headPos);

        if (!state.gripping) {
            // First contact: record the baseline, produce NO velocity yet.
            state.gripping  = true;
            // FLOOR vs WALL is decided by the FACE the hand grabbed, not just depth:
            //   - any TOP face (upward-facing surface) = floor grip — the hand plants
            //     on it and supports you, no matter how high the block is. This is what
            //     lets you stand on / push up from blocks at waist height regardless of
            //     wallStickiness (which only governs SIDE-face wall grips).
            //   - otherwise fall back to the depth rule (grab point well below the
            //     head = reached down to the ground), which covers the no-raycast case
            //     (hand already inside a block, ray missed).
            state.floorGrip = topFace || touchHand.field_1351 < headPos.field_1351 - FLOOR_GRIP_DEPTH;
            state.prevOffset = offset;  // swingHand-based, same as every subsequent tick
            return class_243.field_1353;
        }

        // WALL → FLOOR PROMOTION (one-way, re-checked every tick of the grip).
        // Mantling a step, the hand usually brushes the block's SIDE first (so the
        // grip latches as a wall) and only then lands on TOP. Without promotion the
        // grip stayed "wall" forever, the low-stick slide kicked in, and pushing up
        // a 1-block step was nearly impossible. The moment the hand's ray sees a top
        // face, the grip becomes a supporting floor grip — this also makes sliding
        // up over a wall's top edge a proper ledge grab. One-way only (never floor →
        // wall) so the behaviour can't flip-flop mid-grip.
        if (!state.floorGrip && topFace) {
            state.floorGrip = true;
        }

        // How far your hand moved (relative to head) since last tick = your swing.
        class_243 swing = offset.method_1020(state.prevOffset);
        state.prevOffset = offset;

        // Body moves OPPOSITE to the swing, scaled by pull strength.
        return swing.method_1021(-MovementConfig.pullStrength);
    }

    // -----------------------------------------------------------------------
    // SWING-SPEED AVERAGE  (for the throw)
    // -----------------------------------------------------------------------

    private void ensureSwingHistory() {
        int size = Math.max(1, (int) MovementConfig.velocityHistorySize);
        if (swingHistory == null || swingHistory.length != size) {
            swingHistory = new class_243[size];
            Arrays.fill(swingHistory, class_243.field_1353);
            swingIndex = 0;
            swingAvg = class_243.field_1353;
        }
    }

    private void storeSwing(class_243 v) {
        swingIndex = (swingIndex + 1) % swingHistory.length;
        class_243 oldest = swingHistory[swingIndex];
        swingAvg = swingAvg.method_1019(v.method_1020(oldest).method_1021(1.0 / swingHistory.length));
        swingHistory[swingIndex] = v;
    }

    // -----------------------------------------------------------------------
    // TOUCH TEST
    // -----------------------------------------------------------------------

    // Normal point check — is this position inside/touching any solid block?
    private boolean isTouchingBlock(class_310 client, class_243 handPos) {
        return isTouchingAABB(client, handAABB(handPos));
    }

    // Fall-sweep check: when the player is falling fast the extended-reach
    // endpoint can overshoot a floor entirely in a single tick. We widen the
    // detection box UPWARD by `fallSpeed` (blocks/tick) so any block the hand
    // passed through on the way down is still caught.
    private boolean isTouchingBlockFallSweep(class_310 client, class_243 handPos, double fallSpeed) {
        if (fallSpeed < 0.1) return isTouchingBlock(client, handPos);
        double r = MovementConfig.handRadius;
        // Extend the AABB upward by the fall speed so the sweep covers the full
        // vertical distance the hand could have skipped over this tick.
        class_238 sweepBox = new class_238(
            handPos.field_1352 - r, handPos.field_1351 - r,              handPos.field_1350 - r,
            handPos.field_1352 + r, handPos.field_1351 + r + fallSpeed,  handPos.field_1350 + r
        );
        return isTouchingAABB(client, sweepBox);
    }

    // Core AABB-vs-blocks test — shared by both touch variants above.
    private boolean isTouchingAABB(class_310 client, class_238 box) {
        class_2338 minPos = class_2338.method_49637(box.field_1323, box.field_1322, box.field_1321);
        class_2338 maxPos = class_2338.method_49637(box.field_1320, box.field_1325, box.field_1324);

        for (int x = minPos.method_10263(); x <= maxPos.method_10263(); x++) {
            for (int y = minPos.method_10264(); y <= maxPos.method_10264(); y++) {
                for (int z = minPos.method_10260(); z <= maxPos.method_10260(); z++) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 bs = client.field_1687.method_8320(pos);
                    if (bs.method_26215()) continue;
                    // Ice: hands slip off all faces (slippery, not climbable).
                    // Barrier: server admin block — completely invisible to the mod
                    //          so operators can wall off areas players can't swing past.
                    if (isUngrabbable(bs)) continue;

                    class_265 shape = bs.method_26220(client.field_1687, pos);
                    if (shape.method_1110()) continue;

                    for (class_238 piece : shape.method_1090()) {
                        class_238 worldBox = piece.method_989(pos.method_10263(), pos.method_10264(), pos.method_10260());
                        if (box.method_994(worldBox)) return true;
                    }
                }
            }
        }
        return false;
    }

    // Returns true if any barrier block exists within the given AABB.
    // Used to suppress step assist so players can't walk/boost over admin barriers.
    private static boolean hasBarrierInAABB(class_1937 level, class_238 box) {
        class_2338 min = class_2338.method_49637(box.field_1323, box.field_1322, box.field_1321);
        class_2338 max = class_2338.method_49637(box.field_1320, box.field_1325, box.field_1324);
        for (int x = min.method_10263(); x <= max.method_10263(); x++)
            for (int y = min.method_10264(); y <= max.method_10264(); y++)
                for (int z = min.method_10260(); z <= max.method_10260(); z++)
                    if (level.method_8320(new class_2338(x, y, z)).method_27852(class_2246.field_10499)) return true;
        return false;
    }

    // Blocks that hands cannot grip at all. Routes through isTouchingAABB so it
    // covers every face (wall, floor, ceiling) with a single check.
    //   Barrier — server admin block; the mod treats it as invisible so operators
    //             can fence off areas this mod cannot bypass.
    // NOTE: ice is NOT listed here — ice DOES allow a brief first-contact grip so
    //       the push-off impulse path (above) can fire. Ice just can't be sustained.
    private static boolean isUngrabbable(class_2680 bs) {
        return bs.method_27852(class_2246.field_10499);
    }

    // -----------------------------------------------------------------------
    // WALL-CLIP GUARD
    // -----------------------------------------------------------------------

    // Sweeps the player AABB along each velocity axis using Level.noCollision().
    // Any axis that would enter a solid block this tick has its velocity zeroed.
    // Called at the end of every gripping tick after all grip maths have settled.
    private static class_243 clampToBlocks(class_310 mc, class_746 player, class_243 vel) {
        if (mc.field_1687 == null || vel.method_1027() < 1e-10) return vel;
        class_238 box = player.method_5829();

        // Fast path: the full swept AABB hits nothing → entire movement is safe.
        if (mc.field_1687.method_8587(player, box.method_1012(vel.field_1352, vel.field_1351, vel.field_1350))) return vel;

        // Slow path: at least one axis would clip. Zero each offending component.
        double vx = vel.field_1352, vy = vel.field_1351, vz = vel.field_1350;
        if (vx != 0 && !mc.field_1687.method_8587(player, box.method_1012(vx, 0, 0))) vx = 0;
        if (vy != 0 && !mc.field_1687.method_8587(player, box.method_1012(0, vy, 0))) vy = 0;
        if (vz != 0 && !mc.field_1687.method_8587(player, box.method_1012(0, 0, vz))) vz = 0;
        return new class_243(vx, vy, vz);
    }

    // -----------------------------------------------------------------------
    // LAUNCH STEP BOOST
    // -----------------------------------------------------------------------

    // Called each tick while the player is airborne and NOT gripping.
    // Detects when the player's horizontal movement is blocked by a block
    // that is within stepHeight reach, and adds just enough upward velocity
    // to carry the player over the top edge — preserving horizontal momentum.
    //
    // How it works:
    //   1. Look 0.15 blocks ahead in the velocity direction.
    //   2. Check if that strip is blocked at current height (feet hit a side).
    //   3. If blocked, iterate upward in 1/16-block steps to find the minimum
    //      dy that would give a clear horizontal path (= block top height).
    //   4. If dy ≤ stepHeight, boost vel.y to sqrt(2 * g * dy) * 1.5 so the
    //      player arcs cleanly onto the block top.
    //
    // Only fires when vel.y is below the needed target, so it never cancels
    // an upward throw that is already clearing the obstacle.
    private static void applyLaunchStepBoost(class_310 mc, class_746 player) {
        if (mc.field_1687 == null) return;
        class_243 vel = player.method_18798();

        // Must be moving meaningfully in the horizontal plane.
        double hSq = vel.field_1352 * vel.field_1352 + vel.field_1350 * vel.field_1350;
        if (hSq < 0.008 * 0.008) return;

        // Already going up fast enough, or falling so hard that a step-up
        // would feel wrong — skip.
        if (vel.field_1351 > 0.20) return;
        if (vel.field_1351 < -0.65) return;

        class_238 box = player.method_5829();

        // Project 0.15 blocks ahead in the velocity direction so we catch
        // blocks the player is touching OR is one frame away from touching.
        double hLen = Math.sqrt(hSq);
        double lookX = vel.field_1352 / hLen * 0.15;
        double lookZ = vel.field_1350 / hLen * 0.15;

        // Fast-exit: if horizontal path is already clear, nothing to do.
        if (mc.field_1687.method_8587(player, box.method_1012(lookX, 0, lookZ))) return;
        // Don't boost over barrier blocks — they're admin boundaries.
        if (hasBarrierInAABB(mc.field_1687, box.method_1012(lookX, 0, lookZ))) return;

        // Step iteration: find the smallest upward offset that clears the path.
        double maxStep = MovementConfig.stepHeight;
        double foundStep = -1;
        for (double dy = 0.0625; dy <= maxStep + 0.01; dy += 0.0625) {
            if (mc.field_1687.method_8587(player,
                    box.method_989(0, dy, 0).method_1012(lookX, 0, lookZ))) {
                foundStep = dy;
                break;
            }
        }

        // Path stays blocked all the way to the step limit → can't step over,
        // and tiny steps (< 0.04) are handled by vanilla collision resolution.
        if (foundStep < 0.04) return;

        // Physics: minimum upward velocity to clear `foundStep` blocks =
        //   v = sqrt(2 * g * h)
        // Use effective gravity (respects gravityMultiplier, floor at 0.02 so
        // we get a valid velocity even in near-zero-gravity modes).
        // Multiply by 1.5 for a safety margin — better to slightly overshoot
        // the block top than to barely clip it and fall back.
        double effG    = Math.max(0.02, 0.08 * MovementConfig.gravityMultiplier);
        double boostY  = Math.sqrt(2.0 * effG * foundStep) * 1.5;
        boostY = Math.max(boostY, 0.15);   // floor so tiny steps still get a kick
        boostY = Math.min(boostY, 0.65);   // cap so launching never rockets the player

        if (vel.field_1351 < boostY) {
            player.method_18800(vel.field_1352, boostY, vel.field_1350);
        }
    }

    // -----------------------------------------------------------------------
    // STEP HEIGHT
    // -----------------------------------------------------------------------

    private void applyStepHeight(class_746 player, double value) {
        class_1324 inst = player.method_5996(class_5134.field_47761);
        if (inst == null) return;
        if (savedStepHeight == null) savedStepHeight = inst.method_6201();
        if (inst.method_6201() != value) inst.method_6192(value);
    }

    private void restoreStepHeight(class_746 player) {
        if (savedStepHeight == null) return;
        class_1324 inst = player.method_5996(class_5134.field_47761);
        if (inst != null) inst.method_6192(savedStepHeight);
        savedStepHeight = null;
    }

    // -----------------------------------------------------------------------
    // ICE BLOCK HELPERS
    // -----------------------------------------------------------------------

    // Returns the speed multiplier for the ice block at `pos`:
    //   0.4 → any ice variant (ICE, PACKED_ICE, BLUE_ICE)
    //   0.0 → not ice
    // Kept well below 1.0 so ice surfaces slow you down rather than launching
    // you at high velocity, keeping physics cost low on Quest hardware.
    private static double iceBlockMultiplier(class_310 mc, class_2338 pos) {
        if (mc.field_1687 == null) return 0.0;
        class_2680 bs = mc.field_1687.method_8320(pos);
        if (bs.method_27852(class_2246.field_10295) || bs.method_27852(class_2246.field_10225) || bs.method_27852(class_2246.field_10384)) return 0.4;
        return 0.0;
    }

    // Returns the highest ice multiplier found within ±0.06 blocks of `pos`.
    // clampGrabToSurface() places the grab point exactly on the block face, so a plain
    // BlockPos.containing() may resolve to the adjacent air block rather than the ice
    // itself. Probing all 6 face-adjacent samples guarantees we catch the ice block
    // regardless of which face was hit.
    private static double iceNearMultiplier(class_310 mc, class_243 pos) {
        if (mc.field_1687 == null) return 0.0;
        double d = 0.06;
        double[][] probes = {
            {0, 0, 0}, {d, 0, 0}, {-d, 0, 0},
            {0, d, 0}, {0, -d, 0}, {0, 0, d}, {0, 0, -d}
        };
        double best = 0.0;
        for (double[] o : probes) {
            best = Math.max(best, iceBlockMultiplier(mc,
                    class_2338.method_49637(pos.field_1352 + o[0], pos.field_1351 + o[1], pos.field_1350 + o[2])));
        }
        return best;
    }

    // -----------------------------------------------------------------------
    // HELPERS
    // -----------------------------------------------------------------------

    private class_238 handAABB(class_243 pos) {
        double r = MovementConfig.handRadius;
        return new class_238(pos.field_1352 - r, pos.field_1351 - r, pos.field_1350 - r, pos.field_1352 + r, pos.field_1351 + r, pos.field_1350 + r);
    }

    private class_243 clampArm(class_243 hand, class_243 head) {
        class_243   offset = hand.method_1020(head);
        double len    = offset.method_1033();
        double max    = MovementConfig.maxArmLength;
        return len > max ? head.method_1019(offset.method_1021(max / len)) : hand;
    }

    // Pushes the hand further out along head->hand so you can reach the ground from
    // standing height. Used ONLY for grab detection, not for measuring your swing.
    private class_243 extendReach(class_243 hand, class_243 head) {
        double m = MovementConfig.handReachMultiplier;
        if (m == 1.0) return hand;
        return head.method_1019(hand.method_1020(head).method_1021(m));
    }

    // Raycasts from `origin` (the HEAD) toward touchPoint. If the ray hits a block
    // face before reaching touchPoint, the grab point snaps to that face — so the
    // hand AABB (and its visual cube) can never sink inside a wall or the floor,
    // no matter how hard the player pushes the controller into the block.
    //
    // Returns the full BlockHitResult (location + WHICH FACE was hit) or null on a
    // miss. The face drives the floor-vs-wall grip classification: Direction.UP =
    // supporting top surface, anything else = wall/ceiling.
    //
    // NOTE: the detection AABB used by isTouchingAABB is a cube of side 2*handRadius.
    // The grab-point marker in HandMarkerRenderer uses the same radius — they match.
    private static class_3965 raycastGrab(class_310 mc, class_746 player,
                                               class_243 origin, class_243 touchPoint) {
        if (mc.field_1687 == null) return null;
        class_243 dir = touchPoint.method_1020(origin);
        double dirLenSq = dir.method_1027();
        if (dirLenSq < 1e-10) return null;
        // Start the ray slightly BEHIND the origin so the cast isn't blinded when
        // the head is pressed right up against a block face.
        class_243 start = origin.method_1020(dir.method_1021(0.1 / Math.sqrt(dirLenSq)));
        // COLLIDER mode = solid block faces only; same collision layer the player uses.
        class_3965 hit = mc.field_1687.method_17742(new class_3959(
            start, touchPoint,
            class_3959.class_3960.field_17558,
            class_3959.class_242.field_1348,
            player
        ));
        return hit.method_17783() == class_239.class_240.field_1333 ? null : hit;
    }
}
