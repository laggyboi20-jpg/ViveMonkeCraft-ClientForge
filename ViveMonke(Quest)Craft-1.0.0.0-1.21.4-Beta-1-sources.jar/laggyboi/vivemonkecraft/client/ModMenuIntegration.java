package laggyboi.vivemonkecraft.client;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import java.util.List;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_437;

// =====================================================================
// MOD MENU CONFIG SCREEN
// =====================================================================
//
// This makes a settings screen show up in the "Mods" list (Mod Menu): find
// ViveMonke(Quest)Craft, click the little gear/config button, and you get sliders and
// toggles for everything — no need to edit the .properties file by hand.
//
// It's OPTIONAL: it only does anything if Mod Menu + Cloth Config are installed
// (they're listed under "suggests" in fabric.mod.json). The .properties file
// still works exactly the same either way.
//
// HOW IT WORKS:
//   * Each row reads the current MovementConfig value and, when you hit Save,
//     writes your new value back into MovementConfig AND saves the file.
//   * Because the handler reads MovementConfig live, changes apply immediately.
// =====================================================================

public class ModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        // The config screen is built with Cloth Config. If it's NOT installed, return
        // a factory that makes no screen — that way the game never crashes when you
        // click the config button; you just won't get a screen (use the file / keybind
        // / /vmc instead). Install Cloth Config to enable this screen.
        if (!FabricLoader.getInstance().isModLoaded("cloth-config")
            && !FabricLoader.getInstance().isModLoaded("cloth-config2")) {
            return parent -> null;
        }
        // "parent" is the Mods screen we came from; we return to it on Save/Cancel.
        return parent -> buildScreen(parent);
    }

    private class_437 buildScreen(class_437 parent) {
        // Sync fields from the file first, so the sliders show the latest values.
        MovementConfig.load();

        // PRESET FIX: Cloth Config calls every entry's save consumer IN REGISTRATION
        // ORDER before it calls setSavingRunnable. Because the preset dropdown is
        // registered first, its save consumer would run first — but then EVERY
        // slider's save consumer fires next and overwrites the preset values with the
        // stale on-screen values.
        //
        // Fix: the dropdown only stores the chosen name here. The actual applyPreset()
        // call is deferred to setSavingRunnable, which runs AFTER all slider consumers
        // have already written their values — so the preset wins.
        final String[] pendingPreset = {"— None —"};

        ConfigBuilder builder = ConfigBuilder.create()
            .setParentScreen(parent)
            .setTitle(class_2561.method_43470("ViveMonke(Quest)Craft — Gorilla Locomotion"));

        // Runs last when you press "Save" (after all entry save consumers).
        // Apply the preset HERE so it overwrites whatever the sliders wrote.
        builder.setSavingRunnable(() -> {
            if (!pendingPreset[0].equals("— None —")) applyPreset(pendingPreset[0]);
            MovementConfig.save();
        });

        ConfigEntryBuilder eb = builder.entryBuilder();

        // ====================================================================
        // PRESETS — choose a preset from the dropdown and hit Save to apply.
        // After saving, close and re-open the config screen to see the updated
        // slider values (Cloth Config reads field values at screen-open time).
        // ====================================================================
        ConfigCategory presets = builder.getOrCreateCategory(class_2561.method_43470("Presets"));

        presets.addEntry(eb.startTextDescription(
            class_2561.method_43470("§7Pick a preset and press §fSave§7. Close and re-open this screen to see the updated values you can scroll this menu while presets are open look right there is a height slider."))
            .build());

        presets.addEntry(
            eb.startStringDropdownMenu(class_2561.method_43470("Apply Preset"), "— None —",
                    s -> class_2561.method_43470(s))
                .setSelections(List.of(
                    "— None —",
                    "tutorial",
                    "Default",
                    "Long Arms",
                    "Zero Gravity",
                    "Speed Run"
                ))
                .setDefaultValue("— None —")
                .setSuggestionMode(false)
                .setTooltip(
                    class_2561.method_43470("tutorial    — Use this if you find it hard to move with default."),
                    class_2561.method_43470("Default     — Reset all settings to factory defaults."),
                    class_2561.method_43470("Gorilla Tag — Authentic GT feel: stronger throws, less air drag."),
                    class_2561.method_43470("Zero Gravity— Float after letting go; space-like movement."),
                    class_2561.method_43470("Speed Run   — Very powerful launches, long arms, low air drag.")
                )
                // Just STORE the name — applyPreset() is called in setSavingRunnable
                // (which runs after ALL slider save consumers) so the preset wins.
                .setSaveConsumer(p -> pendingPreset[0] = p)
                .build()
        );


        // ====================================================================
        // MOVEMENT
        // ====================================================================
        ConfigCategory movement = builder.getOrCreateCategory(class_2561.method_43470("Movement"));

        movement.addEntry(eb.startBooleanToggle(class_2561.method_43470("Step assist teleports"), MovementConfig.stepTeleport)
            .setDefaultValue(true)
            .setTooltip(
                class_2561.method_43470("ON = step assist places you directly on top of the ledge (instant)."),
                class_2561.method_43470("OFF = old behaviour: an upward velocity boost arcs you over it."))
            .setSaveConsumer(v -> MovementConfig.stepTeleport = v).build());

        movement.addEntry(eb.startDoubleField(class_2561.method_43470("Push speed"), MovementConfig.pullStrength)
            .setDefaultValue(2.0).setMin(0.0).setMax(8.0)
            .setTooltip(class_2561.method_43470("How strongly your swing moves you. 1.0 = 1:1, higher = faster. (Ignored in anchor mode — that is always 1:1.)"))
            .setSaveConsumer(v -> MovementConfig.pullStrength = v).build());

        movement.addEntry(eb.startDoubleField(class_2561.method_43470("Ground friction (anti-slide)"), MovementConfig.groundFriction)
            .setDefaultValue(0.5).setMin(0.0).setMax(1.0)
            .setTooltip(class_2561.method_43470("1.0 = slide forever, 0.5 = stops fast, 0.2 = near-instant."))
            .setSaveConsumer(v -> MovementConfig.groundFriction = v).build());

        movement.addEntry(eb.startDoubleField(class_2561.method_43470("Air friction"), MovementConfig.airFriction)
            .setDefaultValue(1.0).setMin(0.0).setMax(1.0)
            .setTooltip(
                class_2561.method_43470("How much horizontal speed bleeds off while airborne and NOT gripping."),
                class_2561.method_43470("1.0 = normal Minecraft drag  (velocity × 0.91 each tick)"),
                class_2561.method_43470("0.5 = half drag  (carries momentum further after a throw)"),
                class_2561.method_43470("0.0 = no drag  (throws carry forever — useful in Zero-G)")
            )
            .setSaveConsumer(v -> MovementConfig.airFriction = v).build());

        movement.addEntry(eb.startDoubleField(class_2561.method_43470("Wall stickiness"), MovementConfig.wallStickiness)
            .setDefaultValue(1.0).setMin(0.0).setMax(1.0)
            .setTooltip(class_2561.method_43470("How hard hands cling to walls while gripping. 1.0 = hang forever, 0.5 = slowly slide down, 0.0 = no clinging (gravity pulls you off)."))
            .setSaveConsumer(v -> MovementConfig.wallStickiness = v).build());

        movement.addEntry(eb.startDoubleField(class_2561.method_43470("Floor stickiness"), MovementConfig.floorStickiness)
            .setDefaultValue(1.0).setMin(0.0).setMax(1.0)
            .setTooltip(class_2561.method_43470("How much you slide across the floor while a hand is planted. 1.0 = stop dead (sticks to spot), 0.5 = some glide, 0.0 = ice-like (slides forever)."))
            .setSaveConsumer(v -> MovementConfig.floorStickiness = v).build());

        movement.addEntry(eb.startBooleanToggle(class_2561.method_43470("Ice floor = ice wall (experimental) leave comment which one is better this or default"), MovementConfig.iceFloorWallLogic)
            .setDefaultValue(false)
            .setTooltip(
                class_2561.method_43470("Treat grabbing an ICE FLOOR exactly like an ice WALL: gravity on,"),
                class_2561.method_43470("no anchor glue, pure push-off momentum. Legacy physics only."),
                class_2561.method_43470("Experimental — for testing the feel."))
            .setSaveConsumer(v -> MovementConfig.iceFloorWallLogic = v).build());

        movement.addEntry(eb.startDoubleField(class_2561.method_43470("Jitter filter (minImpulse)"), MovementConfig.minImpulse)
            .setDefaultValue(0.002).setMin(0.0).setMax(0.1)
            .setTooltip(class_2561.method_43470("Movements smaller than this are ignored so a resting hand stays still."))
            .setSaveConsumer(v -> MovementConfig.minImpulse = v).build());

        // ====================================================================
        // REACH & BODY
        // ====================================================================
        ConfigCategory body = builder.getOrCreateCategory(class_2561.method_43470("Reach & Body"));

        body.addEntry(eb.startDoubleField(class_2561.method_43470("Gorilla arm length"), MovementConfig.handReachMultiplier)
            .setDefaultValue(2.5).setMin(1.0).setMax(6.0)
            .setTooltip(class_2561.method_43470("Longer arms = reach the ground with less real-arm reach. 2.5 default, raise to 3.0+"))
            .setSaveConsumer(v -> MovementConfig.handReachMultiplier = v).build());

        body.addEntry(eb.startDoubleField(class_2561.method_43470("Max arm length (blocks)"), MovementConfig.maxArmLength)
            .setDefaultValue(3.0).setMin(1.5).setMax(8.0)
            .setTooltip(class_2561.method_43470("Hard limit on how far a hand can be from your head."))
            .setSaveConsumer(v -> MovementConfig.maxArmLength = v).build());

        body.addEntry(eb.startDoubleField(class_2561.method_43470("Hand grab size"), MovementConfig.handRadius)
            .setDefaultValue(0.12).setMin(0.02).setMax(0.5)
            .setTooltip(class_2561.method_43470("Radius of the hand touch sphere. Bigger = easier to grab."))
            .setSaveConsumer(v -> MovementConfig.handRadius = v).build());

        body.addEntry(eb.startDoubleField(class_2561.method_43470("Hitbox height (legs)"), MovementConfig.hitboxHeightScale)
            .setDefaultValue(0.25).setMin(0.2).setMax(1.0)
            .setTooltip(class_2561.method_43470("Shrinks your collision box height to climb onto blocks. 1.0 = normal, 0.25 = compact (default)."))
            .setSaveConsumer(v -> MovementConfig.hitboxHeightScale = v).build());

        body.addEntry(eb.startBooleanToggle(class_2561.method_43470("Step assist"), MovementConfig.stepAssist)
            .setDefaultValue(true)
            .setTooltip(class_2561.method_43470("Raise step height so legs stop snagging on block edges."))
            .setSaveConsumer(v -> MovementConfig.stepAssist = v).build());

        body.addEntry(eb.startDoubleField(class_2561.method_43470("Step height"), MovementConfig.stepHeight)
            .setDefaultValue(1.5).setMin(0.5).setMax(2.0)
            .setTooltip(class_2561.method_43470("Ledge height you can step over. 0.6 = vanilla, 1.5 = 1.5 blocks (default)."))
            .setSaveConsumer(v -> MovementConfig.stepHeight = v).build());

        // ====================================================================
        // JUMP & GRAVITY
        // ====================================================================
        ConfigCategory jump = builder.getOrCreateCategory(class_2561.method_43470("Jump & Gravity"));

        jump.addEntry(eb.startDoubleField(class_2561.method_43470("Jump threshold"), MovementConfig.velocityLimit)
            .setDefaultValue(0.06).setMin(0.0).setMax(1.0)
            .setTooltip(class_2561.method_43470("You only launch on release if you were moving faster than this."))
            .setSaveConsumer(v -> MovementConfig.velocityLimit = v).build());

        jump.addEntry(eb.startDoubleField(class_2561.method_43470("Jump power"), MovementConfig.jumpMultiplier)
            .setDefaultValue(1.4).setMin(0.0).setMax(5.0)
            .setTooltip(class_2561.method_43470("How much your speed is multiplied into the launch. 1.0 = release speed, 1.4 = boost."))
            .setSaveConsumer(v -> MovementConfig.jumpMultiplier = v).build());

        jump.addEntry(eb.startDoubleField(class_2561.method_43470("Max launch speed"), MovementConfig.maxJumpSpeed)
            .setDefaultValue(1.0).setMin(0.1).setMax(5.0)
            .setTooltip(class_2561.method_43470("Hard cap on launch speed (blocks/tick). 1.0 = 20 blocks/sec."))
            .setSaveConsumer(v -> MovementConfig.maxJumpSpeed = v).build());

        jump.addEntry(eb.startDoubleField(class_2561.method_43470("Jump smoothing (ticks)"), MovementConfig.velocityHistorySize)
            .setDefaultValue(6.0).setMin(1.0).setMax(20.0)
            .setTooltip(class_2561.method_43470("How many ticks of movement are averaged for the launch."))
            .setSaveConsumer(v -> MovementConfig.velocityHistorySize = v).build());

        jump.addEntry(eb.startDoubleField(class_2561.method_43470("Gravity"), MovementConfig.gravityMultiplier)
            .setDefaultValue(1.0).setMin(0.0).setMax(1.0)
            .setTooltip(
                class_2561.method_43470("Scales gravity while airborne and NOT gripping."),
                class_2561.method_43470("1.0 = normal Minecraft gravity  (default)"),
                class_2561.method_43470("0.5 = half gravity  (slow fall, floaty)"),
                class_2561.method_43470("0.0 = zero gravity  (float in place after releasing)"),
                class_2561.method_43470("Can also be changed in-game with /vmc gravity <0-1> (op required).")
            )
            .setSaveConsumer(v -> MovementConfig.gravityMultiplier = v).build());

        // ====================================================================
        // VISUAL
        // ====================================================================
        ConfigCategory visual = builder.getOrCreateCategory(class_2561.method_43470("Visual"));

        visual.addEntry(eb.startBooleanToggle(class_2561.method_43470("Show hand markers"), MovementConfig.showHandMarkers)
            .setDefaultValue(true)
            .setTooltip(class_2561.method_43470("Render split arm lines at your hands. Green = touching a block, red = not."))
            .setSaveConsumer(v -> MovementConfig.showHandMarkers = v).build());

        visual.addEntry(eb.startBooleanToggle(class_2561.method_43470("Clamp hand models to surfaces"), MovementConfig.clampHandModels)
            .setDefaultValue(true)
            .setTooltip(
                class_2561.method_43470("While gripping, the Vivecraft hand model is drawn ON the block face"),
                class_2561.method_43470("instead of sinking inside it (like Gorilla Tag's hand followers)."),
                class_2561.method_43470("Purely visual — physics always uses your real hand."))
            .setSaveConsumer(v -> MovementConfig.clampHandModels = v).build());

        visual.addEntry(eb.startBooleanToggle(class_2561.method_43470("Real Monke (gorilla size)"), MovementConfig.realMonke)
            .setDefaultValue(false)
            .setTooltip(
                class_2561.method_43470("Caps your collision box HEIGHT at 0.5 blocks on both client and"),
                class_2561.method_43470("server so you fit through 1-block tunnels. Height only — width,"),
                class_2561.method_43470("model, camera scale and reach stay normal. Does NOT drop the view."))
            .setSaveConsumer(v -> MovementConfig.realMonke = v).build());

        visual.addEntry(eb.startDoubleField(class_2561.method_43470("Camera height offset"), MovementConfig.cameraHeightOffset)
            .setDefaultValue(0.0).setMin(0.0).setMax(1.5)
            .setTooltip(
                class_2561.method_43470("Blocks to LOWER the VR view + hands. 0 = off."),
                class_2561.method_43470("Trade-off: makes your OWN body model look squashed toward the"),
                class_2561.method_43470("floor (it stays anchored to your feet). Real Monke does not use it."))
            .setSaveConsumer(v -> MovementConfig.cameraHeightOffset = v).build());

        visual.addEntry(eb.startBooleanToggle(class_2561.method_43470("Monke model (no legs)"), MovementConfig.monkeModel)
            .setDefaultValue(false)
            .setTooltip(
                class_2561.method_43470("The Gorilla Tag body: legs removed, torso shortened."),
                class_2561.method_43470("Synced via monke-server — every player with the mod sees every"),
                class_2561.method_43470("other opted-in player legless. Tune the body parts below."))
            .setSaveConsumer(v -> MovementConfig.monkeModel = v).build());

        visual.addEntry(eb.startDoubleField(class_2561.method_43470("Monke torso offset Y"), MovementConfig.modelTorsoOffsetY)
            .setDefaultValue(0.0).setMin(-12.0).setMax(12.0)
            .setTooltip(class_2561.method_43470("Torso up/down in model pixels (1 px = 1/16 block, +down)."))
            .setSaveConsumer(v -> MovementConfig.modelTorsoOffsetY = v).build());

        visual.addEntry(eb.startDoubleField(class_2561.method_43470("Monke torso pitch (deg)"), MovementConfig.modelTorsoPitch)
            .setDefaultValue(-120.0).setMin(-360.0).setMax(360.0)
            .setTooltip(class_2561.method_43470("Torso rotation in degrees — full -360..360 allowed. -120 = GT lean (default)."))
            .setSaveConsumer(v -> MovementConfig.modelTorsoPitch = v).build());

        visual.addEntry(eb.startDoubleField(class_2561.method_43470("Monke torso height scale"), MovementConfig.modelTorsoScaleY)
            .setDefaultValue(0.75).setMin(0.1).setMax(2.0)
            .setTooltip(class_2561.method_43470("Torso height multiplier. 0.75 = a bit shorter than the arms."))
            .setSaveConsumer(v -> MovementConfig.modelTorsoScaleY = v).build());

        visual.addEntry(eb.startDoubleField(class_2561.method_43470("Monke arms offset Y"), MovementConfig.modelArmsOffsetY)
            .setDefaultValue(0.0).setMin(-12.0).setMax(12.0)
            .setTooltip(class_2561.method_43470("Arms up/down in model pixels (+down)."))
            .setSaveConsumer(v -> MovementConfig.modelArmsOffsetY = v).build());

        visual.addEntry(eb.startDoubleField(class_2561.method_43470("Monke arms pitch (deg)"), MovementConfig.modelArmsPitch)
            .setDefaultValue(0.0).setMin(-360.0).setMax(360.0)
            .setTooltip(class_2561.method_43470("Extra arm rotation in degrees (added on top of the swing animation)."))
            .setSaveConsumer(v -> MovementConfig.modelArmsPitch = v).build());

        visual.addEntry(eb.startDoubleField(class_2561.method_43470("Monke head offset Y"), MovementConfig.modelHeadOffsetY)
            .setDefaultValue(0.0).setMin(-12.0).setMax(12.0)
            .setTooltip(class_2561.method_43470("Head up/down in model pixels (+down)."))
            .setSaveConsumer(v -> MovementConfig.modelHeadOffsetY = v).build());

        visual.addEntry(eb.startDoubleField(class_2561.method_43470("Monke head pitch (deg)"), MovementConfig.modelHeadPitch)
            .setDefaultValue(0.0).setMin(-360.0).setMax(360.0)
            .setTooltip(class_2561.method_43470("Extra head rotation in degrees (added on top of look direction)."))
            .setSaveConsumer(v -> MovementConfig.modelHeadPitch = v).build());


        // ====================================================================
        // GT PHYSICS — everything about the anchor-mode port of the official
        // GorillaLocomotion algorithm lives on its own page.
        // ====================================================================
        ConfigCategory gtPage = builder.getOrCreateCategory(class_2561.method_43470("GT Physics"));

        gtPage.addEntry(eb.startBooleanToggle(class_2561.method_43470("GT physics beta (anchor mode) its quite bad if you ask me"), MovementConfig.gtPhysics)
                .setDefaultValue(true)
                .setTooltip(
                        class_2561.method_43470("ON = official GorillaLocomotion algorithm: hands ANCHOR to the spot"),
                        class_2561.method_43470("they touch and your body is dragged 1:1 (Push speed + stickiness ignored)."),
                        class_2561.method_43470("OFF = older speed-based model (swing speed × Push speed)."))
                .setSaveConsumer(v -> MovementConfig.gtPhysics = v).build());

        gtPage.addEntry(eb.startDoubleField(class_2561.method_43470("Push strength"), MovementConfig.gtPushStrength)
                .setDefaultValue(1.0).setMin(0.1).setMax(5.0)
                .setTooltip(
                        class_2561.method_43470("Body movement = hand movement × this."),
                        class_2561.method_43470("1.0 = authentic Gorilla Tag 1:1, 2.0 = twice as far, 0.5 = half."))
                .setSaveConsumer(v -> MovementConfig.gtPushStrength = v).build());

        gtPage.addEntry(eb.startDoubleField(class_2561.method_43470("Drag gain"), MovementConfig.gtDragGain)
                .setDefaultValue(0.30).setMin(0.05).setMax(0.95)
                .setTooltip(
                        class_2561.method_43470("Fraction of the distance to the anchor corrected each tick."),
                        class_2561.method_43470("0.30 = smooth (default), 0.6 = snappier, 0.2 = softer."),
                        class_2561.method_43470("Keep below 1.0 or grabs overshoot and bounce."))
                .setSaveConsumer(v -> MovementConfig.gtDragGain = v).build());

        gtPage.addEntry(eb.startDoubleField(class_2561.method_43470("Unstick distance (blocks)"), MovementConfig.gtUnstickDistance)
                .setDefaultValue(1.0).setMin(0.2).setMax(3.0)
                .setTooltip(
                        class_2561.method_43470("How far a hand may stray from its anchor before the grip releases."),
                        class_2561.method_43470("Official Gorilla Tag uses 1.0."))
                .setSaveConsumer(v -> MovementConfig.gtUnstickDistance = v).build());

        gtPage.addEntry(eb.startDoubleField(class_2561.method_43470("Ice slip"), MovementConfig.gtIceSlip)
                .setDefaultValue(0.95).setMin(0.0).setMax(1.0)
                .setTooltip(
                        class_2561.method_43470("How fast an anchor drifts toward the hand on ice."),
                        class_2561.method_43470("0 = ice grips like stone, 0.95 = push off only (default)."))
                .setSaveConsumer(v -> MovementConfig.gtIceSlip = v).build());

        return builder.build();
    }

    // =========================================================================
    // PRESETS
    // =========================================================================

    // Each preset sets the subset of settings that define its feel.
    // The overall builder.setSavingRunnable(MovementConfig::save) persists
    // everything to disk when the player presses Save.
    private void applyPreset(String preset) {
        switch (preset) {
            case "tutorial":
                //it gives every helping settings turned on
                MovementConfig.pullStrength        = 2.5;
                MovementConfig.groundFriction      = 1.0;
                MovementConfig.airFriction         = 0.1;
                MovementConfig.wallStickiness      = 1.0;
                MovementConfig.floorStickiness     = 1.0;
                MovementConfig.minImpulse          = 0.002;
                MovementConfig.handReachMultiplier = 1.0;
                MovementConfig.velocityLimit       = 0.05;
                MovementConfig.jumpMultiplier      = 1.8;
                MovementConfig.maxArmLength        = 3.0;
                MovementConfig.handRadius          = 0.12;
                MovementConfig.hitboxHeightScale   = 0.25;
                MovementConfig.stepAssist          = true;
                MovementConfig.stepTeleport        = true;
                MovementConfig.stepHeight          = 1.5;
                MovementConfig.jumpMultiplier      = 1.5;
                MovementConfig.maxJumpSpeed        = 1.0;
                MovementConfig.velocityHistorySize = 6;
                MovementConfig.gravityMultiplier   = 1.0;
                MovementConfig.showHandMarkers     = true;
                MovementConfig.monkeModel          = true;
                MovementConfig.realMonke           = true;
                MovementConfig.modelTorsoPitch     = -120.0;
                MovementConfig.gtPhysics           = false;
                break;

            case "Default":
                // Restore every field to its documented default value.
                MovementConfig.pullStrength        = 2.5;
                MovementConfig.groundFriction      = 0.4;
                MovementConfig.airFriction         = 0.1;
                MovementConfig.wallStickiness      = 0.9;
                MovementConfig.floorStickiness     = 1.0;
                MovementConfig.minImpulse          = 0.002;
                MovementConfig.handReachMultiplier = 1.0;
                MovementConfig.velocityLimit       = 0.05;
                MovementConfig.jumpMultiplier      = 1.8;
                MovementConfig.maxArmLength        = 3.0;
                MovementConfig.handRadius          = 0.12;
                MovementConfig.hitboxHeightScale   = 0.25;
                MovementConfig.stepAssist          = false;
                MovementConfig.stepTeleport        = true;
                MovementConfig.stepHeight          = 1.0;
                MovementConfig.maxJumpSpeed        = 1.0;
                MovementConfig.velocityHistorySize = 6;
                MovementConfig.gravityMultiplier   = 1.0;
                MovementConfig.showHandMarkers     = false;
                MovementConfig.monkeModel          = true;
                MovementConfig.realMonke           = true;
                MovementConfig.modelTorsoPitch     = -120.0;
                MovementConfig.gtPhysics           = false;
                break;

            case "Long Arms":
                // Closer to the official Gorilla Tag experience:
                //   - Stronger pull so arm swings feel punchy.
                //   - Lower air drag so throws carry farther.
                //   - Slightly easier throw trigger (lower velocityLimit).
                //   - More powerful launches with a higher cap.
                //   - Walls SLIDE (no clinging) so you keep momentum instead of sticking.
                //   - MONKE MODEL on: the legless GT body with the -120° torso lean.
                MovementConfig.pullStrength        = 2.5;
                MovementConfig.groundFriction      = 0.4;
                MovementConfig.airFriction         = 0.1;
                MovementConfig.wallStickiness      = 0.9;
                MovementConfig.floorStickiness     = 1.0;
                MovementConfig.minImpulse          = 0.002;
                MovementConfig.handReachMultiplier = 3.5;
                MovementConfig.velocityLimit       = 0.05;
                MovementConfig.jumpMultiplier      = 1.8;
                MovementConfig.maxJumpSpeed        = 1.5;
                MovementConfig.velocityHistorySize = 5;
                MovementConfig.gravityMultiplier   = 1.0;
                MovementConfig.showHandMarkers     = true;
                MovementConfig.monkeModel          = true;
                MovementConfig.realMonke           = true;
                MovementConfig.modelTorsoPitch     = -120.0;

                break;

            case "Zero Gravity":
                // Space/floating experience:
                //   - No gravity: you float after releasing a surface.
                //   - Very low air drag: momentum carries indefinitely.
                //   - Bigger throws so you can actually navigate.
                //   - Full wall stickiness so you can push off any surface.
                MovementConfig.gravityMultiplier   = 0.1;
                MovementConfig.airFriction         = 0.05;
                MovementConfig.wallStickiness      = 1.0;
                MovementConfig.floorStickiness     = 0.8;
                MovementConfig.pullStrength        = 2.0;
                MovementConfig.jumpMultiplier      = 2.0;
                MovementConfig.maxJumpSpeed        = 2.5;
                MovementConfig.groundFriction      = 0.9;
                MovementConfig.monkeModel          = true;
                MovementConfig.realMonke           = true;
                MovementConfig.modelTorsoPitch     = -120.0;
                break;

            case "Parkour / Speed Run":
                // Built for covering ground as fast as possible:
                //   - Very high pull strength for huge launches.
                //   - Long gorilla arms to grab from further away.
                //   - Low air drag so speed carries between grabs.
                //   - Fewer history ticks for snappier throw detection.
                //   - High max speed so you can actually rocket.
                MovementConfig.pullStrength        = 5.0;
                MovementConfig.handReachMultiplier = 3.0;
                MovementConfig.maxArmLength        = 4.0;
                MovementConfig.airFriction         = 0.0;
                MovementConfig.jumpMultiplier      = 3.5;
                MovementConfig.maxJumpSpeed        = 3.0;
                MovementConfig.velocityHistorySize = 4;
                MovementConfig.groundFriction      = 0.7;
                MovementConfig.gravityMultiplier   = 1.0;
                MovementConfig.monkeModel          = true;
                MovementConfig.realMonke           = true;
                MovementConfig.modelTorsoPitch     = -120.0;
                break;

            default:
                // "— None —" or anything unrecognised: do nothing.
                break;
        }
    }
}
